"use client";

import React, { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { HeroUpload } from "@/components/HeroUpload";
import { BiometricScannerOverlay } from "@/components/BiometricScannerOverlay";
import { FaceAnalysisHUD } from "@/components/FaceAnalysisHUD";
import { SearchResults } from "@/components/SearchResults";
import { FaceCompareModal } from "@/components/FaceCompareModal";
import { InvestigationDossierModal } from "@/components/InvestigationDossierModal";
import { CompareLabView } from "@/components/CompareLabView";
import { ScammerRegistryView } from "@/components/ScammerRegistryView";
import { OptOutPortalView } from "@/components/OptOutPortalView";
import { ApiPlaygroundView } from "@/components/ApiPlaygroundView";
import { SearchHistoryDrawer } from "@/components/SearchHistoryDrawer";
import { Footer } from "@/components/Footer";
import {
  ShieldAlert,
  Search,
  CheckCircle2,
  Lock,
  Eye,
  Sliders,
  HelpCircle,
  FileSearch,
  Cpu,
  Fingerprint,
} from "lucide-react";
import { playMatchFoundSound, playAlertWarningSound, playBlipSound } from "@/utils/audio";

interface SearchMatch {
  id: number;
  personName: string;
  category: string;
  platform: string;
  profileUrl: string;
  handleOrTitle: string;
  snippet: string;
  imageUrl: string;
  confidenceScore: number;
  matchGrade: "Certain" | "High" | "Uncertain" | "Weak";
  biometricDistance: number;
  isScamFlagged: boolean;
  scamDetails?: {
    aliases?: string[];
    scamType?: string;
    victimReportsCount?: number;
    warningText?: string;
    riskLevel?: "Critical" | "High" | "Medium";
  } | null;
}

interface QueryFaceMeta {
  boundingBox?: { x: number; y: number; width: number; height: number };
  landmarksCount?: number;
  biometricVectorDimensions?: number;
  estimatedAge?: string;
  gender?: string;
  deepfakeProbability?: number;
  facialSymmetry?: number;
  qualityScore?: string;
}

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<"search" | "compare" | "scammers" | "optout" | "api">("search");
  const [isSearching, setIsSearching] = useState(false);
  const [isScanningAnimation, setIsScanningAnimation] = useState(false);
  const [queryImage, setQueryImage] = useState<string | null>(null);
  const [queryName, setQueryName] = useState<string>("");

  const [searchId, setSearchId] = useState<string>("");
  const [queryFaceMeta, setQueryFaceMeta] = useState<QueryFaceMeta | null>(null);
  const [matches, setMatches] = useState<SearchMatch[]>([]);
  const [stats, setStats] = useState<{
    totalIndexedFaces?: string;
    processingTimeMs?: number;
    matchesFound?: number;
  }>({});

  const [selectedCompareMatch, setSelectedCompareMatch] = useState<SearchMatch | null>(null);
  const [isDossierOpen, setIsDossierOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [historyCount, setHistoryCount] = useState(2);

  // Trigger facial search
  const handleStartSearch = async (
    imageUrl: string,
    imageName: string,
    sampleTargetId?: number
  ) => {
    setQueryImage(imageUrl);
    setQueryName(imageName);
    setIsSearching(true);
    setIsScanningAnimation(true);
    setActiveTab("search");

    try {
      const res = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageUrl,
          imageName,
          sampleTargetId,
        }),
      });

      const data = await res.json();

      // Give 2.2s for scanning HUD animation to render nicely
      setTimeout(() => {
        setIsScanningAnimation(false);
        setIsSearching(false);

        if (data.success) {
          setSearchId(data.searchId);
          setQueryFaceMeta(data.queryFace);
          setMatches(data.matches);
          setStats(data.stats);
          setHistoryCount((prev) => prev + 1);

          // If flagged as scam, play alert, else victory sound
          const hasScam = data.matches.some((m: SearchMatch) => m.isScamFlagged);
          if (hasScam) {
            playAlertWarningSound();
          } else {
            playMatchFoundSound();
          }
        } else {
          alert(data.error || "Search failed");
        }
      }, 2200);
    } catch (err) {
      console.error(err);
      setIsScanningAnimation(false);
      setIsSearching(false);
      alert("Error executing facial recognition search.");
    }
  };

  const handleResetSearch = () => {
    setQueryImage(null);
    setQueryName("");
    setMatches([]);
    setQueryFaceMeta(null);
    setSearchId("");
    playBlipSound(700);
  };

  const handleSelectPastSearch = (imageUrl: string, imageName: string) => {
    handleStartSearch(imageUrl, imageName);
  };

  return (
    <div className="min-h-screen bg-[#060913] text-slate-100 flex flex-col justify-between cyber-grid">
      {/* Top Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openHistory={() => setIsHistoryOpen(true)}
        historyCount={historyCount}
      />

      <main className="flex-1">
        {/* TAB 1: FACE SEARCH HERO ENGINE */}
        {activeTab === "search" && (
          <div className="pt-4 pb-16">
            {/* If Scanning Animation Active */}
            {isScanningAnimation && queryImage ? (
              <div className="mx-auto max-w-2xl px-4 py-12 text-center">
                <BiometricScannerOverlay
                  imageSrc={queryImage}
                  isScanning={isScanningAnimation}
                />
              </div>
            ) : matches.length > 0 && queryImage ? (
              /* Search Results View */
              <div className="mx-auto max-w-6xl px-4 sm:px-6 space-y-6 pt-2">
                {/* Face Forensic HUD */}
                {queryFaceMeta && <FaceAnalysisHUD data={queryFaceMeta} />}

                {/* Match Results Grid */}
                <SearchResults
                  queryImage={queryImage}
                  matches={matches}
                  stats={stats}
                  onOpenCompare={(match) => setSelectedCompareMatch(match)}
                  onOpenDossier={() => setIsDossierOpen(true)}
                  onResetSearch={handleResetSearch}
                />
              </div>
            ) : (
              /* Empty Hero Upload State */
              <div>
                <HeroUpload
                  onStartSearch={handleStartSearch}
                  isSearching={isSearching}
                />

                {/* Trust & Architecture Showcase Below Hero */}
                <div className="mx-auto max-w-6xl px-4 sm:px-6 mt-16 space-y-16">
                  {/* Feature Highlights Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-6 backdrop-blur-sm space-y-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
                        <Fingerprint className="h-5 w-5" />
                      </div>
                      <h3 className="text-base font-bold text-white">
                        Biometric Facial Geometry
                      </h3>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Rather than matching file metadata or names, FaceCheck measures 68 distinct 3D landmarks, eye-to-jaw angles, and nose contour vectors invariant to lighting and age.
                      </p>
                    </div>

                    <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-6 backdrop-blur-sm space-y-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-500/10 border border-red-500/30 text-red-400">
                        <ShieldAlert className="h-5 w-5" />
                      </div>
                      <h3 className="text-base font-bold text-white">
                        Catfish & Romance Scam Shield
                      </h3>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Cross-references uploaded photos with 24,000+ known catfish personas, stolen military doctor identities, crypto fraud reports, and county court blotters.
                      </p>
                    </div>

                    <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-6 backdrop-blur-sm space-y-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                        <Lock className="h-5 w-5" />
                      </div>
                      <h3 className="text-base font-bold text-white">
                        Zero Photo Retention & Opt-Out
                      </h3>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        We never store your uploaded search images after session execution. Our self-service Opt-Out portal allows immediate suppression from the global neural index.
                      </p>
                    </div>
                  </div>

                  {/* Frequently Asked Questions */}
                  <div className="rounded-3xl border border-slate-800 bg-slate-900/50 p-6 sm:p-10 backdrop-blur-md">
                    <div className="flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-wider text-cyan-400 mb-2">
                      <HelpCircle className="h-4 w-4" />
                      Frequently Answered Questions
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-6">
                      How Facial Recognition Search Works
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-300">
                      <div className="space-y-1.5 rounded-xl bg-slate-950/60 p-4 border border-slate-800/80">
                        <h4 className="font-bold text-white text-sm">
                          How does FaceCheck search across the internet?
                        </h4>
                        <p className="text-slate-400 leading-relaxed">
                          Our autonomous web crawlers index publicly accessible web pages, social media profiles, news articles, video thumbnails, and registry databases. When you upload a photo, our deep neural net converts the face into a 512-dimensional vector and scans our index in milliseconds.
                        </p>
                      </div>

                      <div className="space-y-1.5 rounded-xl bg-slate-950/60 p-4 border border-slate-800/80">
                        <h4 className="font-bold text-white text-sm">
                          Can it detect AI deepfakes and synthetic faces?
                        </h4>
                        <p className="text-slate-400 leading-relaxed">
                          Yes! FaceCheck inspects images for GAN generation artifacts, frequency domain anomalies, irregular corneal reflections, and pupil asymmetry to determine whether a face is a real person or AI-generated.
                        </p>
                      </div>

                      <div className="space-y-1.5 rounded-xl bg-slate-950/60 p-4 border border-slate-800/80">
                        <h4 className="font-bold text-white text-sm">
                          How do I remove my face from search results?
                        </h4>
                        <p className="text-slate-400 leading-relaxed">
                          Click on the &quot;Opt-Out / Remove&quot; tab in the top navigation. You can submit an automated takedown request that immediately adds your biometric hash to our exclusion filter.
                        </p>
                      </div>

                      <div className="space-y-1.5 rounded-xl bg-slate-950/60 p-4 border border-slate-800/80">
                        <h4 className="font-bold text-white text-sm">
                          Is FaceCheck free to test?
                        </h4>
                        <p className="text-slate-400 leading-relaxed">
                          Yes. You can test unlimited searches, compare biometrics side-by-side, access our romance scammer directory, and test our developer API directly in this web sandbox.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: BIOMETRIC COMPARE LAB */}
        {activeTab === "compare" && <CompareLabView />}

        {/* TAB 3: SCAMMER & CATFISH REGISTRY */}
        {activeTab === "scammers" && (
          <ScammerRegistryView
            onSearchTarget={(imageUrl, name, id) => {
              handleStartSearch(imageUrl, name, id);
            }}
          />
        )}

        {/* TAB 4: OPT-OUT PORTAL */}
        {activeTab === "optout" && <OptOutPortalView />}

        {/* TAB 5: DEVELOPER API PLAYGROUND */}
        {activeTab === "api" && <ApiPlaygroundView />}
      </main>

      {/* Modals & Drawers */}
      <FaceCompareModal
        isOpen={!!selectedCompareMatch}
        onClose={() => setSelectedCompareMatch(null)}
        queryImage={queryImage || ""}
        match={selectedCompareMatch}
      />

      <InvestigationDossierModal
        isOpen={isDossierOpen}
        onClose={() => setIsDossierOpen(false)}
        searchId={searchId}
        queryImage={queryImage || ""}
        faceAnalysis={queryFaceMeta || undefined}
        matches={matches}
      />

      <SearchHistoryDrawer
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onSelectPastSearch={handleSelectPastSearch}
      />

      {/* Footer */}
      <Footer onNavigateTab={(tab) => setActiveTab(tab)} />
    </div>
  );
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { optOutRequests, indexedProfiles } from "@/db/schema";
import { ilike } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const { fullName, email, reason, governmentIdProvided, faceImageUrl } = await req.json();

    if (!fullName || !email) {
      return NextResponse.json(
        { error: "Full legal name and valid email address are required." },
        { status: 400 }
      );
    }

    const requestId = "OPT-" + Math.floor(1000 + Math.random() * 9000) + "-CONF";

    // Insert request
    await db.insert(optOutRequests).values({
      id: requestId,
      fullName,
      email,
      reason: reason || "Individual privacy rights and personal safety request",
      governmentIdProvided: !!governmentIdProvided,
      faceImageUrl: faceImageUrl || null,
      status: "approved_suppressed",
    });

    // Suppress profiles matching this name if any
    const firstToken = fullName.trim().split(" ")[0];
    if (firstToken && firstToken.length > 2) {
      await db
        .update(indexedProfiles)
        .set({ isSuppressed: true })
        .where(ilike(indexedProfiles.personName, `%${firstToken}%`));
    }

    return NextResponse.json({
      success: true,
      requestId,
      message: `Takedown request ${requestId} has been executed. Biometric signature matching ${fullName} is permanently suppressed from all future public facial search queries.`,
      suppressedAt: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json(
      { error: (error as Error).message },
      { status: 500 }
    );
  }
}

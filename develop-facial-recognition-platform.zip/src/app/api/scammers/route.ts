import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { indexedProfiles } from "@/db/schema";
import { or, eq, like } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get("q")?.toLowerCase();

    const results = await db
      .select()
      .from(indexedProfiles)
      .where(
        or(
          eq(indexedProfiles.isScamFlagged, true),
          eq(indexedProfiles.category, "scammer"),
          eq(indexedProfiles.category, "mugshot")
        )
      );

    const filtered = search
      ? results.filter(
          (r) =>
            r.personName.toLowerCase().includes(search) ||
            r.snippet.toLowerCase().includes(search) ||
            r.scamDetails?.aliases?.some((a) => a.toLowerCase().includes(search))
        )
      : results;

    return NextResponse.json({
      success: true,
      count: filtered.length,
      scammers: filtered,
    });
  } catch (error) {
    return NextResponse.json(
      { error: (error as Error).message },
      { status: 500 }
    );
  }
}

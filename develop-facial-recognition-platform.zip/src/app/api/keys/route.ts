import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { apiKeys } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const keys = await db.select().from(apiKeys).orderBy(desc(apiKeys.createdAt)).limit(10);
    return NextResponse.json({ success: true, keys });
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { name = "Production App Key" } = await req.json().catch(() => ({}));
    const newKey = "fc_live_" + Array.from({ length: 32 }, () => Math.floor(Math.random() * 36).toString(36)).join("");
    const id = "key_" + Math.random().toString(36).substring(2, 10);

    const created = await db
      .insert(apiKeys)
      .values({
        id,
        key: newKey,
        name,
        requestsUsed: 0,
        rateLimit: 2500,
      })
      .returning();

    return NextResponse.json({ success: true, key: created[0] });
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}

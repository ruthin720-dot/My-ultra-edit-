import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { searchLogs } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const history = await db
      .select()
      .from(searchLogs)
      .orderBy(desc(searchLogs.createdAt))
      .limit(20);

    return NextResponse.json({ success: true, history });
  } catch (error) {
    return NextResponse.json(
      { error: (error as Error).message },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (id) {
      await db.delete(searchLogs).where(eq(searchLogs.id, id));
    } else {
      await db.delete(searchLogs);
    }

    return NextResponse.json({ success: true, message: "History cleared" });
  } catch (error) {
    return NextResponse.json(
      { error: (error as Error).message },
      { status: 500 }
    );
  }
}

import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "FaceCheck.ID — Next-Gen AI Facial Recognition Search Engine",
  description: "Search 850M+ indexed faces across social media, dating apps, scam registries, and public records. Reverse face search, deepfake detection & biometric identity verification.",
  keywords: "face search, reverse image search, facial recognition, facecheck, catfish detector, scammer lookup, ai face search",
  openGraph: {
    title: "FaceCheck.ID — Next-Gen AI Facial Recognition Search Engine",
    description: "Search millions of online faces with biometric AI. Unmask catfishers, verify identities, check romance scammers, and find social media profiles.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="min-h-screen bg-[#060913] text-slate-100 antialiased selection:bg-cyan-500/30 selection:text-cyan-200">
        {children}
      </body>
    </html>
  );
}

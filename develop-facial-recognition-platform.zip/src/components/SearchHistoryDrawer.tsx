"use client";

import React, { useEffect, useState } from "react";
import { X, Trash2, History, RotateCcw, Clock, Sparkles } from "lucide-react";
import { playBlipSound } from "@/utils/audio";

interface SearchHistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPastSearch: (imageUrl: string, imageName: string) => void;
}

interface SearchLogItem {
  id: string;
  sourceImageUrl: string;
  sourceImageName: string;
  detectedFacesCount: number;
  searchQueryMeta?: {
    estimatedAge?: string;
    gender?: string;
    deepfakeScore?: number;
    processingTimeMs?: number;
  };
  resultsCount: number;
  topMatchScore: number;
  createdAt: string;
}

export function SearchHistoryDrawer({
  isOpen,
  onClose,
  onSelectPastSearch,
}: SearchHistoryDrawerProps) {
  const [history, setHistory] = useState<SearchLogItem[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadHistory();
    }
  }, [isOpen]);

  const loadHistory = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/search/history");
      const data = await res.json();
      if (data.history) {
        setHistory(data.history);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleClearHistory = async () => {
    if (!confirm("Are you sure you want to clear your facial search history?")) return;
    playBlipSound(700);
    try {
      await fetch("/api/search/history", { method: "DELETE" });
      setHistory([]);
    } catch (err) {
      console.error(err);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm">
      <div className="relative w-full max-w-md bg-slate-950 border-l border-cyan-500/30 p-6 flex flex-col justify-between shadow-2xl">
        {/* Header */}
        <div>
          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
            <div className="flex items-center gap-2">
              <History className="h-5 w-5 text-cyan-400" />
              <h3 className="text-base font-bold text-white">Search History</h3>
              <span className="rounded bg-slate-800 px-2 py-0.5 text-xs font-mono text-cyan-300">
                {history.length}
              </span>
            </div>
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* List of past searches */}
          <div className="space-y-3 max-h-[70vh] overflow-y-auto pr-1">
            {loading ? (
              <p className="text-xs text-slate-400 text-center py-8">Loading history logs...</p>
            ) : history.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                <Clock className="h-8 w-8 mx-auto mb-2 text-slate-600" />
                No past searches recorded in this session.
              </div>
            ) : (
              history.map((item) => (
                <div
                  key={item.id}
                  className="group rounded-xl border border-slate-800 bg-slate-900/60 p-3 hover:border-cyan-500/40 hover:bg-slate-900 transition-all flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="h-12 w-12 rounded-lg bg-slate-800 overflow-hidden shrink-0 border border-slate-700">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={
                          item.sourceImageUrl.startsWith("data:")
                            ? "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg"
                            : item.sourceImageUrl
                        }
                        alt="Query Face"
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate group-hover:text-cyan-300">
                        {item.sourceImageName}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono flex items-center gap-2 mt-0.5">
                        <span className="text-cyan-400">{item.topMatchScore}% Top Match</span>
                        <span>•</span>
                        <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onSelectPastSearch(item.sourceImageUrl, item.sourceImageName);
                      onClose();
                      playBlipSound(900);
                    }}
                    title="Re-run search"
                    className="rounded-lg bg-cyan-500/10 p-2 text-cyan-300 hover:bg-cyan-500/20"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Footer with Clear All */}
        {history.length > 0 && (
          <div className="pt-4 border-t border-slate-800">
            <button
              onClick={handleClearHistory}
              className="w-full flex items-center justify-center gap-2 rounded-xl border border-red-500/30 bg-red-950/20 py-2.5 text-xs font-semibold text-red-400 hover:bg-red-950/40 transition-colors"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Clear Search History
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

"use client";

import React, { useState, useEffect } from "react";
import { Code2, Key, Play, Copy, Check, Terminal, ExternalLink, RefreshCw } from "lucide-react";
import { playBlipSound } from "@/utils/audio";

export function ApiPlaygroundView() {
  const [apiKey, setApiKey] = useState("fc_live_79a2ef3948b84920b721e");
  const [keysList, setKeysList] = useState<Array<{ id: string; key: string; name: string }>>([]);
  const [activeLang, setActiveLang] = useState<"curl" | "python" | "javascript">("curl");
  const [testImageUrl, setTestImageUrl] = useState("https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg");
  const [testThreshold, setTestThreshold] = useState(70);
  const [isExecuting, setIsExecuting] = useState(false);
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [copiedSnippet, setCopiedSnippet] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);

  useEffect(() => {
    fetchKeys();
  }, []);

  const fetchKeys = async () => {
    try {
      const res = await fetch("/api/keys");
      const data = await res.json();
      if (data.keys && data.keys.length > 0) {
        setKeysList(data.keys);
        setApiKey(data.keys[0].key);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleGenerateNewKey = async () => {
    playBlipSound(900);
    try {
      const res = await fetch("/api/keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "Dev Sandbox Key " + new Date().toLocaleTimeString() }),
      });
      const data = await res.json();
      if (data.key) {
        setKeysList((prev) => [data.key, ...prev]);
        setApiKey(data.key.key);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleExecuteApi = async () => {
    setIsExecuting(true);
    playBlipSound(880);
    try {
      const res = await fetch("/api/v1/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          image_url: testImageUrl,
          threshold: testThreshold,
          limit: 5,
        }),
      });
      const data = await res.json();
      setApiResponse(JSON.stringify(data, null, 2));
    } catch (err) {
      setApiResponse(JSON.stringify({ error: (err as Error).message }, null, 2));
    } finally {
      setIsExecuting(false);
    }
  };

  const snippets = {
    curl: `curl -X POST https://api.facecheck.id/v1/search \\
  -H "Authorization: Bearer ${apiKey}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "image_url": "${testImageUrl}",
    "threshold": ${testThreshold},
    "limit": 10
  }'`,
    python: `import requests

url = "https://api.facecheck.id/v1/search"
headers = {
    "Authorization": "Bearer ${apiKey}",
    "Content-Type": "application/json"
}
payload = {
    "image_url": "${testImageUrl}",
    "threshold": ${testThreshold},
    "limit": 10
}

response = requests.post(url, json=payload, headers=headers)
results = response.json()
print("Matches found:", results.get("matches_count"))`,
    javascript: `const response = await fetch("https://api.facecheck.id/v1/search", {
  method: "POST",
  headers: {
    "Authorization": "Bearer ${apiKey}",
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    image_url: "${testImageUrl}",
    threshold: ${testThreshold},
    limit: 10
  })
});

const data = await response.json();
console.log("Indexed Face Matches:", data.matches);`,
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(snippets[activeLang]);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  const handleCopyKey = () => {
    navigator.clipboard.writeText(apiKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 space-y-8">
      {/* Title */}
      <div>
        <div className="inline-flex items-center gap-2 rounded-full border border-purple-500/30 bg-purple-500/10 px-3.5 py-1 text-xs font-semibold text-purple-300 mb-3 font-mono">
          <Code2 className="h-3.5 w-3.5 text-purple-400" />
          <span>REST API & Webhooks</span>
        </div>
        <h2 className="text-3xl font-black text-white">
          Developer API & <span className="text-purple-400">Integration Console</span>
        </h2>
        <p className="text-sm text-slate-400 mt-1 max-w-2xl">
          Integrate FaceCheck biometric facial reverse search directly into your KYC workflows, fraud prevention pipelines, and OSINT investigation platforms.
        </p>
      </div>

      {/* API Key Manager */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 backdrop-blur-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
            <Key className="h-3.5 w-3.5 text-purple-400" />
            <span>ACTIVE LIVE SECRET KEY</span>
          </div>
          <div className="flex items-center gap-3 mt-1.5">
            <code className="rounded-lg bg-black/60 px-3 py-1 font-mono text-xs text-purple-300 border border-purple-500/30 truncate max-w-xs sm:max-w-md">
              {apiKey}
            </code>
            <button
              onClick={handleCopyKey}
              className="text-xs text-slate-400 hover:text-white"
              title="Copy Key"
            >
              {copiedKey ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
            </button>
          </div>
        </div>

        <button
          onClick={handleGenerateNewKey}
          className="flex items-center gap-2 rounded-xl bg-purple-600/20 px-4 py-2 text-xs font-bold text-purple-300 border border-purple-500/40 hover:bg-purple-600/30 transition-colors self-start sm:self-auto"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Generate New Key
        </button>
      </div>

      {/* Code Snippets & Test Runner */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Code Snippets */}
        <div className="rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden flex flex-col">
          <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900/80 px-4 py-2.5">
            <div className="flex items-center gap-2">
              <Terminal className="h-4 w-4 text-slate-400" />
              <div className="flex gap-1">
                {(["curl", "python", "javascript"] as const).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => setActiveLang(lang)}
                    className={`rounded px-2.5 py-1 text-xs font-mono font-medium capitalize ${
                      activeLang === lang
                        ? "bg-purple-500/20 text-purple-300 border border-purple-500/40"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    {lang}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1 rounded bg-slate-800 px-2.5 py-1 text-xs text-slate-300 hover:bg-slate-700 font-mono"
            >
              {copiedSnippet ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
              {copiedSnippet ? "Copied" : "Copy"}
            </button>
          </div>

          <pre className="p-4 text-xs font-mono text-slate-300 overflow-x-auto flex-1 leading-relaxed">
            <code>{snippets[activeLang]}</code>
          </pre>
        </div>

        {/* Right: Live Interactive Test Runner */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2 text-xs font-mono font-bold text-white uppercase">
                <Play className="h-3.5 w-3.5 text-cyan-400" />
                Live Endpoint Sandbox
              </div>
              <span className="rounded bg-emerald-500/10 px-2 py-0.5 text-[10px] font-mono text-emerald-400 border border-emerald-500/30">
                POST /api/v1/search
              </span>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  Query Image URL (image_url)
                </label>
                <input
                  type="text"
                  value={testImageUrl}
                  onChange={(e) => setTestImageUrl(e.target.value)}
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  Confidence Threshold: {testThreshold}%
                </label>
                <input
                  type="range"
                  min="50"
                  max="95"
                  value={testThreshold}
                  onChange={(e) => setTestThreshold(Number(e.target.value))}
                  className="w-full h-2 bg-slate-800 rounded-lg accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div>
            <button
              onClick={handleExecuteApi}
              disabled={isExecuting}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-purple-500 to-cyan-500 py-2.5 text-xs font-bold text-slate-950 hover:opacity-90 transition-opacity shadow-lg shadow-purple-500/20 disabled:opacity-50 mt-4"
            >
              {isExecuting ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
              {isExecuting ? "Executing REST Query..." : "Send Live API Request"}
            </button>

            {/* Response Viewer */}
            {apiResponse && (
              <div className="mt-4 rounded-xl bg-slate-950 p-3 border border-slate-800">
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pb-1 mb-1 border-b border-slate-800">
                  <span className="text-emerald-400">HTTP 200 OK</span>
                  <span>Latency: ~340ms</span>
                </div>
                <pre className="text-[11px] font-mono text-slate-300 max-h-48 overflow-y-auto">
                  {apiResponse}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

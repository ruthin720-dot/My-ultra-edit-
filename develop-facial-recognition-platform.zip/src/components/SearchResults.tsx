"use client";

import React, { useState } from "react";
import {
  ExternalLink,
  Sliders,
  AlertTriangle,
  Printer,
  RotateCcw,
  ShieldCheck,
  CheckCircle,
  Share2,
  Filter,
  Check,
} from "lucide-react";
import { playBlipSound } from "@/utils/audio";

interface MatchItem {
  id: number;
  personName: string;
  category: string;
  platform: string;
  profileUrl: string;
  handleOrTitle: string;
  snippet: string;
  imageUrl: string;
  confidenceScore: number;
  matchGrade: "Certain" | "High" | "Uncertain" | "Weak";
  biometricDistance: number;
  isScamFlagged: boolean;
  scamDetails?: {
    aliases?: string[];
    scamType?: string;
    victimReportsCount?: number;
    warningText?: string;
    riskLevel?: "Critical" | "High" | "Medium";
  } | null;
}

interface SearchResultsProps {
  queryImage: string;
  matches: MatchItem[];
  stats: {
    totalIndexedFaces?: string;
    processingTimeMs?: number;
    matchesFound?: number;
  };
  onOpenCompare: (match: MatchItem) => void;
  onOpenDossier: () => void;
  onResetSearch: () => void;
}

export function SearchResults({
  queryImage,
  matches,
  stats,
  onOpenCompare,
  onOpenDossier,
  onResetSearch,
}: SearchResultsProps) {
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [gradeFilter, setGradeFilter] = useState<string>("all");
  const [copiedLink, setCopiedLink] = useState(false);

  const categories = [
    { id: "all", label: "All Sources" },
    { id: "social", label: "Social Media" },
    { id: "dating", label: "Dating Apps" },
    { id: "scammer", label: "Scammer & Catfish" },
    { id: "mugshot", label: "Mugshots & Court" },
    { id: "news", label: "News & Media" },
  ];

  const filteredMatches = matches.filter((m) => {
    if (categoryFilter !== "all" && m.category !== categoryFilter) return false;
    if (gradeFilter === "certain" && m.confidenceScore < 90) return false;
    if (gradeFilter === "high" && (m.confidenceScore < 80 || m.confidenceScore >= 90)) return false;
    if (gradeFilter === "uncertain" && (m.confidenceScore < 70 || m.confidenceScore >= 80)) return false;
    if (gradeFilter === "weak" && m.confidenceScore >= 70) return false;
    return true;
  });

  const getPlatformIconColor = (platform: string) => {
    switch (platform.toLowerCase()) {
      case "instagram":
        return "text-pink-400 bg-pink-500/10 border-pink-500/30";
      case "linkedin":
        return "text-sky-400 bg-sky-500/10 border-sky-500/30";
      case "x (twitter)":
        return "text-slate-300 bg-slate-500/10 border-slate-500/30";
      case "tiktok":
        return "text-cyan-300 bg-cyan-500/10 border-cyan-500/30";
      case "tinder":
        return "text-rose-400 bg-rose-500/10 border-rose-500/30";
      case "bumble":
        return "text-amber-400 bg-amber-500/10 border-amber-500/30";
      case "mugshots.org":
      case "arrestrecords.com":
        return "text-red-400 bg-red-500/10 border-red-500/30";
      default:
        return "text-cyan-400 bg-cyan-500/10 border-cyan-500/30";
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-cyan-300 border-cyan-400/50 bg-cyan-500/20";
    if (score >= 80) return "text-emerald-300 border-emerald-400/50 bg-emerald-500/20";
    if (score >= 70) return "text-amber-300 border-amber-400/50 bg-amber-500/20";
    return "text-slate-400 border-slate-600 bg-slate-800";
  };

  const handleCopyLink = () => {
    if (typeof navigator !== "undefined") {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Stats & Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl border border-slate-800 bg-slate-900/80 p-4 sm:p-5 backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <h2 className="text-lg font-bold text-white">
              Search Results: <span className="text-cyan-400">{matches.length} matches found</span>
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Indexed scan completed in <strong className="text-slate-200">{(stats.processingTimeMs || 380) / 1000}s</strong> across 854M+ biometric records.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onOpenDossier}
            className="flex items-center gap-1.5 rounded-xl bg-cyan-500/20 px-3.5 py-2 text-xs font-semibold text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30 transition-colors"
          >
            <Printer className="h-4 w-4" />
            Export Intelligence Dossier
          </button>
          <button
            onClick={handleCopyLink}
            className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 transition-colors"
          >
            {copiedLink ? <Check className="h-4 w-4 text-emerald-400" /> : <Share2 className="h-4 w-4" />}
            {copiedLink ? "Copied" : "Share"}
          </button>
          <button
            onClick={onResetSearch}
            className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 transition-colors"
          >
            <RotateCcw className="h-4 w-4" />
            New Search
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Category Tabs */}
        <div className="flex overflow-x-auto gap-1.5 pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setCategoryFilter(cat.id);
                playBlipSound(750);
              }}
              className={`rounded-xl px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                categoryFilter === cat.id
                  ? "bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20"
                  : "bg-slate-900/60 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Confidence Tier Filter */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <Filter className="h-3.5 w-3.5 text-slate-400" />
          <select
            value={gradeFilter}
            onChange={(e) => setGradeFilter(e.target.value)}
            className="rounded-xl border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-slate-300 focus:border-cyan-400 focus:outline-none"
          >
            <option value="all">All Confidence Tiers</option>
            <option value="certain">Certain Match (90-100%)</option>
            <option value="high">High Confidence (80-89%)</option>
            <option value="uncertain">Uncertain (70-79%)</option>
            <option value="weak">Weak (&lt;70%)</option>
          </select>
        </div>
      </div>

      {/* Matches Grid */}
      {filteredMatches.length === 0 ? (
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-12 text-center">
          <p className="text-slate-400 text-sm">No matches found for the selected filter combination.</p>
          <button
            onClick={() => {
              setCategoryFilter("all");
              setGradeFilter("all");
            }}
            className="mt-3 text-cyan-400 hover:underline text-xs"
          >
            Reset all filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredMatches.map((match) => (
            <div
              key={match.id}
              className={`group flex flex-col justify-between overflow-hidden rounded-2xl border transition-all duration-200 ${
                match.isScamFlagged
                  ? "border-red-500/50 bg-slate-950/90 shadow-lg shadow-red-500/10"
                  : "border-slate-800/80 bg-slate-900/60 hover:border-cyan-500/50 hover:bg-slate-900/90"
              }`}
            >
              {/* Card Image Header with Confidence Badge */}
              <div className="relative aspect-video w-full overflow-hidden bg-slate-950">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={match.imageUrl}
                  alt={match.personName}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />

                {/* Score pill */}
                <div className="absolute top-2.5 right-2.5 z-10">
                  <span
                    className={`rounded-full px-2.5 py-1 text-xs font-mono font-bold border backdrop-blur-md ${getScoreColor(
                      match.confidenceScore
                    )}`}
                  >
                    {match.confidenceScore}% {match.matchGrade}
                  </span>
                </div>

                {/* Platform Tag */}
                <div className="absolute bottom-2.5 left-2.5 z-10">
                  <span
                    className={`rounded-lg px-2.5 py-1 text-xs font-bold border backdrop-blur-md ${getPlatformIconColor(
                      match.platform
                    )}`}
                  >
                    {match.platform}
                  </span>
                </div>
              </div>

              {/* Scammer Alert Ribbon if Flagged */}
              {match.isScamFlagged && (
                <div className="flex items-center gap-2 bg-red-950/90 px-3.5 py-2 border-y border-red-500/40 text-red-200 text-xs">
                  <AlertTriangle className="h-4 w-4 text-red-400 shrink-0" />
                  <span className="font-semibold truncate">
                    CATFISH WARNING: Reported {match.scamDetails?.victimReportsCount || 14} times
                  </span>
                </div>
              )}

              {/* Card Body */}
              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="text-sm font-bold text-white line-clamp-1 group-hover:text-cyan-300 transition-colors">
                    {match.handleOrTitle}
                  </h3>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Subject: <span className="text-slate-200 font-medium">{match.personName}</span>
                  </div>
                  <p className="text-xs text-slate-400 line-clamp-3 mt-2 leading-relaxed">
                    {match.snippet}
                  </p>
                </div>

                {/* Scammer Details Box if Present */}
                {match.isScamFlagged && match.scamDetails && (
                  <div className="rounded-xl bg-red-950/40 p-2.5 border border-red-500/30 text-[11px] text-red-300 space-y-1">
                    <div className="font-semibold flex items-center justify-between">
                      <span>Scam Type: {match.scamDetails.scamType}</span>
                      <span className="text-red-400 font-bold uppercase">{match.scamDetails.riskLevel} RISK</span>
                    </div>
                    {match.scamDetails.warningText && (
                      <p className="text-red-300/80 text-[10px] line-clamp-2">
                        {match.scamDetails.warningText}
                      </p>
                    )}
                  </div>
                )}

                {/* Card Action Buttons */}
                <div className="pt-3 border-t border-slate-800/80 flex items-center gap-2">
                  <button
                    onClick={() => {
                      onOpenCompare(match);
                      playBlipSound(850);
                    }}
                    className="flex-1 flex items-center justify-center gap-1.5 rounded-xl border border-cyan-500/30 bg-cyan-500/10 py-2 text-xs font-semibold text-cyan-300 hover:bg-cyan-500/20 transition-colors"
                  >
                    <Sliders className="h-3.5 w-3.5" />
                    Biometrics Compare
                  </button>

                  <a
                    href={match.profileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center rounded-xl border border-slate-700 bg-slate-800/80 p-2 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
                    title="Open external source"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

"use client";

import React, { useState } from "react";
import { ShieldCheck, Lock, CheckCircle2, AlertCircle, FileText, ArrowRight } from "lucide-react";
import { playBlipSound, playMatchFoundSound } from "@/utils/audio";

export function OptOutPortalView() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [reason, setReason] = useState("Individual privacy rights and personal safety request");
  const [governmentIdProvided, setGovernmentIdProvided] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<{
    requestId: string;
    message: string;
    suppressedAt: string;
  } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !email.trim()) {
      alert("Please enter your legal name and contact email.");
      return;
    }

    setIsSubmitting(true);
    playBlipSound(880);

    try {
      const res = await fetch("/api/opt-out", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName,
          email,
          reason,
          governmentIdProvided,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setResult(data);
        playMatchFoundSound();
      } else {
        alert(data.error || "Takedown submission failed");
      }
    } catch (err) {
      console.error(err);
      alert("Submission error. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 space-y-8">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3.5 py-1 text-xs font-semibold text-emerald-300 mb-3">
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
          <span>Biometric Privacy & Takedown Rights</span>
        </div>
        <h2 className="text-3xl font-black text-white">
          Opt-Out & <span className="text-emerald-400">Remove Your Face</span>
        </h2>
        <p className="text-sm text-slate-400 mt-2">
          We respect personal privacy and autonomy. If your face appears in public open-source web indexes and you wish to suppress it from FaceCheck search results, submit a verified removal request below.
        </p>
      </div>

      {/* Main Form or Confirmation */}
      {result ? (
        <div className="rounded-3xl border border-emerald-500/40 bg-slate-900/90 p-8 text-center space-y-5 backdrop-blur-md">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400">
            <CheckCircle2 className="h-8 w-8" />
          </div>

          <h3 className="text-2xl font-bold text-white">Biometric Signature Suppressed</h3>
          <p className="text-sm text-slate-300 max-w-lg mx-auto">
            {result.message}
          </p>

          <div className="mx-auto max-w-sm rounded-xl bg-slate-950 p-4 border border-slate-800 text-xs font-mono space-y-1">
            <div className="text-slate-400">Tracking Reference:</div>
            <div className="text-emerald-400 font-bold text-base">{result.requestId}</div>
            <div className="text-slate-500 text-[10px]">Timestamp: {result.suppressedAt}</div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => {
                setResult(null);
                setFullName("");
                setEmail("");
              }}
              className="text-xs text-cyan-400 hover:underline"
            >
              Submit another removal request
            </button>
          </div>
        </div>
      ) : (
        <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 sm:p-8 backdrop-blur-md">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Full Legal Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Elena Rostova"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Email Address for Confirmation *
                </label>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Removal Reason
              </label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-2.5 text-xs text-white focus:border-cyan-400 focus:outline-none"
              >
                <option value="Individual privacy rights and personal safety request">
                  Individual privacy rights and personal safety request
                </option>
                <option value="My photo was stolen or impersonated in a catfish scam">
                  My photo was stolen or impersonated in a catfish scam
                </option>
                <option value="Legal protection, harassment prevention, or restraining order">
                  Legal protection, harassment prevention, or restraining order
                </option>
                <option value="Expunged court record or corrected public index">
                  Expunged court record or corrected public index
                </option>
              </select>
            </div>

            <div className="pt-2">
              <label className="flex items-start gap-3 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={governmentIdProvided}
                  onChange={(e) => setGovernmentIdProvided(e.target.checked)}
                  className="mt-0.5 h-4 w-4 rounded border-slate-700 bg-slate-800 text-emerald-500 focus:ring-emerald-400 accent-emerald-500"
                />
                <span className="text-xs text-slate-400">
                  <strong className="text-slate-200">Identity Declaration:</strong> I attest under penalty of perjury that I am the individual depicted in the requested suppression profile or authorized to act on their behalf.
                </span>
              </label>
            </div>

            <div className="pt-3">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-6 py-3 text-xs font-bold text-slate-950 hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/20 disabled:opacity-50"
              >
                <Lock className="h-4 w-4" />
                {isSubmitting ? "Suppressing Biometric Signature..." : "Submit Immediate Face Suppression"}
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </form>

          {/* Privacy Guarantee Note */}
          <div className="mt-8 pt-6 border-t border-slate-800 text-xs text-slate-500 space-y-2">
            <div className="flex items-center gap-2 text-slate-400 font-semibold font-mono text-[11px]">
              <Lock className="h-3.5 w-3.5 text-emerald-400" />
              OUR BIOMETRIC ZERO-STORAGE COMMITMENT
            </div>
            <p>
              FaceCheck.ID does not create permanent profiles of individuals. When you submit a suppression request, your facial vector signature is added to an exclusion list, preventing our neural crawler from returning matches in future queries.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

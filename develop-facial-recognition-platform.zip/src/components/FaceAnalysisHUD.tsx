"use client";

import React from "react";
import { ShieldCheck, AlertTriangle, Eye, Sparkles, Binary, CheckCircle } from "lucide-react";

interface FaceAnalysisHUDProps {
  data: {
    estimatedAge?: string;
    gender?: string;
    deepfakeProbability?: number;
    facialSymmetry?: number;
    qualityScore?: string;
    biometricVectorDimensions?: number;
  };
}

export function FaceAnalysisHUD({ data }: FaceAnalysisHUDProps) {
  const deepfakeProb = data.deepfakeProbability ?? 3.2;
  const isAiGenerated = deepfakeProb > 50;
  const symmetry = data.facialSymmetry ?? 94.2;

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 sm:p-5 backdrop-blur-md">
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-4">
        <div className="flex items-center gap-2">
          <Eye className="h-4 w-4 text-cyan-400" />
          <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
            Biometric Analysis & Forensic Quality
          </h3>
        </div>
        <span className="rounded bg-emerald-500/10 px-2 py-0.5 text-[11px] font-semibold text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
          <CheckCircle className="h-3 w-3" />
          High Quality Face Capture
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        {/* Deepfake / AI Face Detector */}
        <div className="rounded-xl bg-slate-950/60 p-3 border border-slate-800/90">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>AI Deepfake Risk</span>
            {isAiGenerated ? (
              <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
            ) : (
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
            )}
          </div>
          <div className="text-lg font-bold font-mono">
            {isAiGenerated ? (
              <span className="text-amber-400">{deepfakeProb}% (Synthetic)</span>
            ) : (
              <span className="text-emerald-400">{deepfakeProb}% (Authentic)</span>
            )}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">
            {isAiGenerated ? "Potential GAN / Diffusion Artifacts" : "Genuine Camera Capture"}
          </p>
        </div>

        {/* Estimated Demographics */}
        <div className="rounded-xl bg-slate-950/60 p-3 border border-slate-800/90">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Estimated Age</span>
            <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
          </div>
          <div className="text-lg font-bold font-mono text-cyan-300">
            {data.estimatedAge || "26 - 32 yrs"}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">
            {data.gender || "Female (98.4%)"}
          </p>
        </div>

        {/* Facial Symmetry */}
        <div className="rounded-xl bg-slate-950/60 p-3 border border-slate-800/90">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Facial Symmetry</span>
            <span className="text-[10px] font-mono text-cyan-400">IPD: OK</span>
          </div>
          <div className="text-lg font-bold font-mono text-cyan-300">
            {symmetry}%
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">
            Inter-Pupillary Ratio 1:1.618
          </p>
        </div>

        {/* Embedding Dimensions */}
        <div className="rounded-xl bg-slate-950/60 p-3 border border-slate-800/90">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Neural Vector</span>
            <Binary className="h-3.5 w-3.5 text-purple-400" />
          </div>
          <div className="text-lg font-bold font-mono text-purple-300">
            512-D
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5 truncate font-mono">
            Cosine Invariant L2
          </p>
        </div>
      </div>
    </div>
  );
}

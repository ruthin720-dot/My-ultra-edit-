"use client";

import React from "react";
import { ShieldCheck, Heart, AlertTriangle, Scale, Lock, ExternalLink } from "lucide-react";

interface FooterProps {
  onNavigateTab: (tab: "search" | "compare" | "scammers" | "optout" | "api") => void;
}

export function Footer({ onNavigateTab }: FooterProps) {
  return (
    <footer className="mt-20 border-t border-slate-900 bg-[#05070f] text-slate-400 text-xs py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand & Mission */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-lg font-black tracking-tight text-white">
                FaceCheck<span className="text-cyan-400">.ID</span>
              </span>
              <span className="rounded bg-cyan-500/20 px-1.5 py-0.5 text-[9px] font-bold text-cyan-300">
                AI SEARCH
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Leading biometric facial reverse search engine indexing public open-source web pages. Helping online daters, businesses, and citizens protect themselves from identity fraud, romance catfishing, and impersonation.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-emerald-400 font-mono">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
              All Neural Inference Nodes Operational
            </div>
          </div>

          {/* Quick Tools */}
          <div className="space-y-2">
            <h4 className="font-bold uppercase tracking-wider text-white text-xs font-mono">
              Biometric Tools
            </h4>
            <ul className="space-y-1.5">
              <li>
                <button
                  onClick={() => onNavigateTab("search")}
                  className="hover:text-cyan-400 transition-colors"
                >
                  Face Search Engine
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab("compare")}
                  className="hover:text-cyan-400 transition-colors"
                >
                  Face Comparison Lab (1-to-1)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab("scammers")}
                  className="hover:text-cyan-400 transition-colors"
                >
                  Romance Scammer Registry
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab("api")}
                  className="hover:text-cyan-400 transition-colors"
                >
                  Developer API & Webhooks
                </button>
              </li>
            </ul>
          </div>

          {/* Privacy & Safety */}
          <div className="space-y-2">
            <h4 className="font-bold uppercase tracking-wider text-white text-xs font-mono">
              Privacy & Ethics
            </h4>
            <ul className="space-y-1.5">
              <li>
                <button
                  onClick={() => onNavigateTab("optout")}
                  className="text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-1 font-semibold"
                >
                  <Lock className="h-3 w-3" />
                  Opt-Out / Remove My Face
                </button>
              </li>
              <li>
                <span className="text-slate-500">Child Protection (Strictly 0 Index)</span>
              </li>
              <li>
                <span className="text-slate-500">Zero Query Photo Retention</span>
              </li>
              <li>
                <span className="text-slate-500">GDPR & CCPA Compliant</span>
              </li>
            </ul>
          </div>

          {/* Safety Disclaimer */}
          <div className="space-y-2 rounded-xl bg-slate-900/40 p-4 border border-slate-800/80">
            <div className="flex items-center gap-1.5 text-amber-400 font-semibold text-xs">
              <AlertTriangle className="h-3.5 w-3.5" />
              Safety & Stalking Warning
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              FaceCheck is strictly intended for personal security and fraud verification. It is against our terms to use this service to stalk, harass, blackmail, or violate the personal boundaries of any individual.
            </p>
          </div>
        </div>

        {/* Bottom credits */}
        <div className="border-t border-slate-900 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} FaceCheck.ID. All rights reserved. Open-source facial indexing.
          </div>
          <div className="flex items-center gap-4">
            <span>Indexed: 854M+ Faces</span>
            <span>•</span>
            <span>Speed: ~0.38s</span>
            <span>•</span>
            <span>Precision: 99.4%</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

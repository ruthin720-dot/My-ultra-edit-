"use client";

import React, { useEffect, useState } from "react";
import { Cpu, ShieldCheck, Search, Database } from "lucide-react";
import { playScanRadarSound } from "@/utils/audio";

interface BiometricScannerOverlayProps {
  imageSrc: string;
  isScanning: boolean;
  onScanComplete?: () => void;
}

export function BiometricScannerOverlay({
  imageSrc,
  isScanning,
}: BiometricScannerOverlayProps) {
  const [stageIndex, setStageIndex] = useState(0);
  const [progress, setProgress] = useState(12);

  const stages = [
    { label: "Isolating facial bounding box & pupillary landmarks...", icon: Search },
    { label: "Constructing 68-point 3D biometric Delaunay mesh...", icon: Cpu },
    { label: "Synthesizing 512-dimensional deep neural vector...", icon: Cpu },
    { label: "Analyzing synthetic deepfake & GAN artifacts...", icon: ShieldCheck },
    { label: "Crawling 854M+ indexed faces across social, dating & legal databases...", icon: Database },
  ];

  useEffect(() => {
    if (!isScanning) {
      setStageIndex(0);
      setProgress(10);
      return;
    }

    playScanRadarSound();

    const stageInterval = setInterval(() => {
      setStageIndex((prev) => (prev < stages.length - 1 ? prev + 1 : prev));
      playScanRadarSound();
    }, 700);

    const progressInterval = setInterval(() => {
      setProgress((prev) => (prev < 96 ? prev + Math.floor(Math.random() * 8 + 4) : 96));
    }, 180);

    return () => {
      clearInterval(stageInterval);
      clearInterval(progressInterval);
    };
  }, [isScanning, stages.length]);

  return (
    <div className="relative mx-auto w-full max-w-md overflow-hidden rounded-2xl border border-cyan-500/50 bg-slate-950/80 shadow-2xl shadow-cyan-500/20">
      {/* Target Image Frame */}
      <div className="relative aspect-square w-full bg-slate-900 overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={imageSrc}
          alt="Target Subject Face"
          className="h-full w-full object-cover filter brightness-95 contrast-105"
        />

        {/* Cyber Scanning Laser Line */}
        <div className="pointer-events-none absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#00f2fe] animate-scan z-20" />

        {/* Biometric Target Reticle Corners */}
        <div className="pointer-events-none absolute inset-6 sm:inset-10 border-2 border-cyan-400/40 rounded-xl z-10">
          {/* Corner brackets */}
          <span className="absolute -top-1.5 -left-1.5 h-6 w-6 border-t-2 border-l-2 border-cyan-400"></span>
          <span className="absolute -top-1.5 -right-1.5 h-6 w-6 border-t-2 border-r-2 border-cyan-400"></span>
          <span className="absolute -bottom-1.5 -left-1.5 h-6 w-6 border-b-2 border-l-2 border-cyan-400"></span>
          <span className="absolute -bottom-1.5 -right-1.5 h-6 w-6 border-b-2 border-r-2 border-cyan-400"></span>

          {/* Center Crosshair */}
          <div className="absolute inset-0 flex items-center justify-center opacity-60">
            <div className="h-10 w-10 border border-cyan-400/60 rounded-full animate-ping opacity-30"></div>
            <div className="h-6 w-6 border border-cyan-300 rounded-full flex items-center justify-center">
              <div className="h-1.5 w-1.5 bg-cyan-400 rounded-full"></div>
            </div>
          </div>
        </div>

        {/* Simulated Biometric Mesh Points */}
        <svg className="pointer-events-none absolute inset-0 h-full w-full opacity-70 z-15" viewBox="0 0 100 100">
          {/* Eyebrows & Eyes */}
          <circle cx="38" cy="38" r="1.2" fill="#00f2fe" />
          <circle cx="43" cy="37" r="1.2" fill="#00f2fe" />
          <circle cx="62" cy="37" r="1.2" fill="#00f2fe" />
          <circle cx="67" cy="38" r="1.2" fill="#00f2fe" />
          {/* Pupils */}
          <circle cx="40" cy="42" r="1.8" fill="#10b981" />
          <circle cx="65" cy="42" r="1.8" fill="#10b981" />
          {/* Nose bridge */}
          <line x1="52" y1="40" x2="52" y2="52" stroke="#00f2fe" strokeWidth="0.5" strokeDasharray="1,1" />
          <circle cx="52" cy="54" r="1.4" fill="#00f2fe" />
          {/* Lips */}
          <circle cx="44" cy="68" r="1.2" fill="#00f2fe" />
          <circle cx="52" cy="66" r="1.2" fill="#00f2fe" />
          <circle cx="60" cy="68" r="1.2" fill="#00f2fe" />
          <circle cx="52" cy="72" r="1.2" fill="#00f2fe" />
          {/* Jaw Contour */}
          <path
            d="M 28 48 Q 30 75 52 86 Q 74 75 76 48"
            fill="none"
            stroke="#00f2fe"
            strokeWidth="0.8"
            strokeDasharray="2,2"
            opacity="0.8"
          />
        </svg>

        {/* HUD Top Left Stats */}
        <div className="absolute top-3 left-3 z-20 rounded bg-black/60 px-2 py-1 font-mono text-[10px] text-cyan-300 backdrop-blur-md border border-cyan-500/30">
          <span>VECTOR_512: LIVE</span>
        </div>

        {/* HUD Top Right Latency */}
        <div className="absolute top-3 right-3 z-20 rounded bg-black/60 px-2 py-1 font-mono text-[10px] text-emerald-400 backdrop-blur-md border border-emerald-500/30">
          <span>LATENCY: 0.38s</span>
        </div>
      </div>

      {/* Progress & Live Step HUD */}
      <div className="p-4 bg-slate-950/90 border-t border-cyan-900/40">
        <div className="flex items-center justify-between text-xs mb-2">
          <div className="flex items-center gap-2 text-cyan-300 font-semibold font-mono">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping"></span>
            NEURAL_ENGINE_ACTIVE
          </div>
          <span className="font-mono text-cyan-400 font-bold">{progress}%</span>
        </div>

        {/* Progress Bar */}
        <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden mb-3">
          <div
            className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-emerald-400 transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Current Active Step */}
        <div className="flex items-center gap-2.5 text-xs text-slate-300 bg-slate-900/90 p-2 rounded-lg border border-slate-800">
          {(() => {
            const CurrentIcon = stages[stageIndex]?.icon || Cpu;
            return <CurrentIcon className="h-4 w-4 text-cyan-400 shrink-0 animate-spin" />;
          })()}
          <span className="truncate">{stages[stageIndex]?.label}</span>
        </div>
      </div>
    </div>
  );
}

"use client";

import React, { useState, useEffect } from "react";
import {
  Scan,
  Shield,
  Layers,
  Code2,
  History,
  Volume2,
  VolumeX,
  AlertTriangle,
  Scale,
  Sparkles,
} from "lucide-react";
import { getAudioMuted, toggleAudioMute, playBlipSound } from "@/utils/audio";

interface HeaderProps {
  activeTab: "search" | "compare" | "scammers" | "optout" | "api";
  setActiveTab: (tab: "search" | "compare" | "scammers" | "optout" | "api") => void;
  openHistory: () => void;
  historyCount: number;
}

export function Header({ activeTab, setActiveTab, openHistory, historyCount }: HeaderProps) {
  const [muted, setMuted] = useState(false);
  const [liveFaceCount, setLiveFaceCount] = useState(854209140);

  useEffect(() => {
    setMuted(getAudioMuted());
    const interval = setInterval(() => {
      setLiveFaceCount((prev) => prev + Math.floor(Math.random() * 5 + 1));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleMuteToggle = () => {
    const nextState = toggleAudioMute();
    setMuted(nextState);
    if (!nextState) playBlipSound(1000);
  };

  interface NavItem {
    id: "search" | "compare" | "scammers" | "optout" | "api";
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }

  const navItems: NavItem[] = [
    { id: "search", label: "Face Search", icon: Scan },
    { id: "compare", label: "Compare Lab", icon: Scale },
    { id: "scammers", label: "Catfish & Scammers", icon: AlertTriangle, badge: "ALERT" },
    { id: "optout", label: "Opt-Out / Remove", icon: Shield },
    { id: "api", label: "Developer API", icon: Code2 },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-cyan-950/60 bg-[#060913]/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Brand / Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setActiveTab("search");
              playBlipSound(880);
            }}
            className="group flex items-center gap-2.5 text-left focus:outline-none"
          >
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500/20 via-blue-600/20 to-purple-600/20 p-0.5 shadow-lg shadow-cyan-500/10 border border-cyan-500/40 group-hover:border-cyan-400 transition-colors">
              <Scan className="h-5 w-5 text-cyan-400 transition-transform group-hover:scale-110" />
              <span className="absolute -top-0.5 -right-0.5 flex h-2.5 w-2.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-cyan-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-black tracking-tight text-white">
                  FaceCheck<span className="text-cyan-400">.ID</span>
                </span>
                <span className="rounded bg-cyan-500/20 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-cyan-300 border border-cyan-500/30">
                  AI PRO
                </span>
              </div>
              <p className="text-[11px] font-medium text-slate-400 hidden sm:block">
                Facial Biometrics & Reverse Search Engine
              </p>
            </div>
          </button>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1 bg-slate-900/60 p-1 rounded-xl border border-slate-800">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  playBlipSound(800);
                }}
                className={`relative flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  isActive
                    ? "bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shadow-sm shadow-cyan-500/20"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
                }`}
              >
                <Icon className={`h-3.5 w-3.5 ${isActive ? "text-cyan-400" : "text-slate-400"}`} />
                {item.label}
                {item.badge && (
                  <span className="rounded bg-red-500/20 px-1 py-0.2 text-[9px] font-bold text-red-400 border border-red-500/30">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Right side stats & utilities */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Live Index Counter */}
          <div className="hidden md:flex items-center gap-2 rounded-lg bg-slate-900/80 px-2.5 py-1.5 border border-slate-800 text-xs">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-slate-400 font-mono text-[11px]">Index:</span>
            <span className="font-mono font-bold text-slate-200 text-[11px]">
              {liveFaceCount.toLocaleString()}
            </span>
          </div>

          {/* Search History */}
          <button
            onClick={() => {
              openHistory();
              playBlipSound(700);
            }}
            title="Search History"
            className="relative flex items-center gap-1.5 rounded-lg bg-slate-900/80 p-2 sm:px-3 sm:py-1.5 border border-slate-800 text-xs text-slate-300 hover:border-slate-700 hover:text-white transition-colors"
          >
            <History className="h-4 w-4 text-cyan-400" />
            <span className="hidden sm:inline font-medium">History</span>
            {historyCount > 0 && (
              <span className="rounded-full bg-cyan-500/20 px-1.5 text-[10px] font-bold text-cyan-300 border border-cyan-500/40">
                {historyCount}
              </span>
            )}
          </button>

          {/* Sound Mute Toggle */}
          <button
            onClick={handleMuteToggle}
            title={muted ? "Unmute Cyber Audio" : "Mute Cyber Audio"}
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700 transition-colors"
          >
            {muted ? <VolumeX className="h-4 w-4 text-slate-500" /> : <Volume2 className="h-4 w-4 text-cyan-400" />}
          </button>
        </div>
      </div>

      {/* Mobile navigation tab scroll */}
      <div className="lg:hidden flex overflow-x-auto border-t border-slate-800/80 px-4 py-2 gap-2 scrollbar-none bg-slate-950/60">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                playBlipSound(800);
              }}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                isActive
                  ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                  : "text-slate-400 hover:text-slate-200 bg-slate-900/60 border border-slate-800"
              }`}
            >
              <Icon className="h-3 w-3" />
              {item.label}
              {item.badge && (
                <span className="rounded bg-red-500/20 px-1 text-[9px] font-bold text-red-400">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </header>
  );
}

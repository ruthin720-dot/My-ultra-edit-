"use client";

import React, { useState } from "react";
import {
  Scale,
  UploadCloud,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Eye,
  Sparkles,
  RefreshCw,
} from "lucide-react";
import { playBlipSound, playMatchFoundSound } from "@/utils/audio";

export function CompareLabView() {
  const [imageA, setImageA] = useState<string>(
    "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
  );
  const [imageB, setImageB] = useState<string>(
    "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
  );
  const [isComparing, setIsComparing] = useState(false);
  const [result, setResult] = useState<{
    similarity: number;
    distance: number;
    verdict: string;
    confidenceLevel: string;
    biometrics: {
      interPupillaryDistanceDelta: string;
      jawContourVariance: string;
      noseBridgeAngleDelta: string;
      zygomaticArchSymmetry: string;
    };
  } | null>(null);
  const [blendOpacity, setBlendOpacity] = useState(50);
  const [showMesh, setShowMesh] = useState(true);

  const presetA = [
    { label: "Elena Vance (Target A)", url: "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" },
    { label: "Dr. Sarah Lin", url: "https://images.pexels.com/photos/14208763/pexels-photo-14208763.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" },
    { label: "Marcus Brody", url: "https://images.pexels.com/photos/26150471/pexels-photo-26150471.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" },
  ];

  const presetB = [
    { label: "Elena Vance (Catfish profile)", url: "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" },
    { label: "Alex Rivera", url: "https://images.pexels.com/photos/30701542/pexels-photo-30701542.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" },
    { label: "Arthur Pendelton", url: "https://images.pexels.com/photos/33680674/pexels-photo-33680674.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" },
  ];

  const handleFileUpload = (file: File, target: "A" | "B") => {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        if (target === "A") setImageA(e.target.result as string);
        else setImageB(e.target.result as string);
        playBlipSound(900);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRunComparison = async () => {
    setIsComparing(true);
    playBlipSound(850);
    try {
      const res = await fetch("/api/compare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageA, imageB }),
      });
      const data = await res.json();
      setResult(data);
      if (data.similarity >= 85) {
        playMatchFoundSound();
      } else {
        playBlipSound(600);
      }
    } catch (err) {
      console.error("Comparison error:", err);
    } finally {
      setIsComparing(false);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 space-y-8">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 rounded-full border border-cyan-500/30 bg-cyan-500/10 px-3.5 py-1 text-xs font-semibold text-cyan-300 mb-3">
          <Scale className="h-3.5 w-3.5 text-cyan-400" />
          <span>Biometric 1-to-1 Verification Lab</span>
        </div>
        <h2 className="text-3xl font-black text-white">
          Compare Two Faces for <span className="text-cyan-400">Biometric Likeness</span>
        </h2>
        <p className="text-sm text-slate-400 mt-2">
          Verify whether two photos portray the same person or different individuals. Measures 68 3D landmarks, eye distance ratios, and jaw contours.
        </p>
      </div>

      {/* Upload Dual View */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Face Subject A */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
              SUBJECT PHOTO A
            </span>
            <label className="cursor-pointer text-xs text-slate-400 hover:text-cyan-300">
              Upload custom
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], "A")}
              />
            </label>
          </div>

          <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={imageA} alt="Subject A" className="h-full w-full object-cover" />
            {showMesh && (
              <svg className="absolute inset-0 h-full w-full pointer-events-none opacity-60" viewBox="0 0 100 100">
                <circle cx="38" cy="38" r="1.5" fill="#00f2fe" />
                <circle cx="62" cy="38" r="1.5" fill="#00f2fe" />
                <circle cx="50" cy="52" r="1.5" fill="#00f2fe" />
                <path d="M 32 46 Q 50 82 68 46" fill="none" stroke="#00f2fe" strokeWidth="0.8" strokeDasharray="2,2" />
              </svg>
            )}
          </div>

          <div className="flex flex-wrap gap-1.5">
            <span className="text-[11px] text-slate-500 font-mono self-center">Presets:</span>
            {presetA.map((p, idx) => (
              <button
                key={idx}
                onClick={() => setImageA(p.url)}
                className="rounded-lg bg-slate-800/80 px-2.5 py-1 text-[11px] text-slate-300 hover:bg-slate-700"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Face Subject B */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
              SUBJECT PHOTO B
            </span>
            <label className="cursor-pointer text-xs text-slate-400 hover:text-emerald-300">
              Upload custom
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], "B")}
              />
            </label>
          </div>

          <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={imageB} alt="Subject B" className="h-full w-full object-cover" />
            {showMesh && (
              <svg className="absolute inset-0 h-full w-full pointer-events-none opacity-60" viewBox="0 0 100 100">
                <circle cx="38" cy="38" r="1.5" fill="#10b981" />
                <circle cx="62" cy="38" r="1.5" fill="#10b981" />
                <circle cx="50" cy="52" r="1.5" fill="#10b981" />
                <path d="M 32 46 Q 50 82 68 46" fill="none" stroke="#10b981" strokeWidth="0.8" strokeDasharray="2,2" />
              </svg>
            )}
          </div>

          <div className="flex flex-wrap gap-1.5">
            <span className="text-[11px] text-slate-500 font-mono self-center">Presets:</span>
            {presetB.map((p, idx) => (
              <button
                key={idx}
                onClick={() => setImageB(p.url)}
                className="rounded-lg bg-slate-800/80 px-2.5 py-1 text-[11px] text-slate-300 hover:bg-slate-700"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Compare Button */}
      <div className="text-center">
        <button
          onClick={handleRunComparison}
          disabled={isComparing}
          className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 px-8 py-3.5 text-sm font-bold text-slate-950 hover:from-cyan-400 hover:to-blue-500 transition-all shadow-xl shadow-cyan-500/20 disabled:opacity-50"
        >
          {isComparing ? (
            <RefreshCw className="h-4 w-4 animate-spin" />
          ) : (
            <Scale className="h-4 w-4" />
          )}
          {isComparing ? "Analyzing Biometric Vector Geometry..." : "Run Biometric Comparison"}
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>

      {/* Comparison Results Card */}
      {result && (
        <div className="rounded-3xl border border-cyan-500/40 bg-slate-900/90 p-6 sm:p-8 backdrop-blur-md space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black font-mono text-cyan-300">
                  {result.similarity}% Likeness
                </span>
                <span
                  className={`rounded-lg px-2.5 py-0.5 text-xs font-bold font-mono border ${
                    result.similarity >= 85
                      ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                      : result.similarity >= 65
                      ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
                      : "bg-red-500/20 text-red-300 border-red-500/40"
                  }`}
                >
                  {result.confidenceLevel} Match
                </span>
              </div>
              <p className="text-sm font-semibold text-white mt-1">{result.verdict}</p>
            </div>

            <button
              onClick={() => setShowMesh(!showMesh)}
              className="text-xs text-cyan-400 hover:underline flex items-center gap-1.5 self-start"
            >
              <Eye className="h-3.5 w-3.5" />
              {showMesh ? "Hide Biometric Landmarks" : "Show Biometric Landmarks"}
            </button>
          </div>

          {/* Superimposition blend slider */}
          <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-300 mb-2 font-mono">
              <span>PHOTO A</span>
              <span>SUPERIMPOSITION OVERLAY</span>
              <span>PHOTO B</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={blendOpacity}
              onChange={(e) => setBlendOpacity(Number(e.target.value))}
              className="h-2 w-full appearance-none rounded-lg bg-slate-800 accent-cyan-400 cursor-pointer"
            />
          </div>

          {/* Biometrics details grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
            <div className="rounded-xl bg-slate-950 p-3.5 border border-slate-800">
              <span className="text-slate-500 block text-[11px]">Euclidean Distance</span>
              <span className="text-base font-bold text-cyan-400">{result.distance}</span>
            </div>
            <div className="rounded-xl bg-slate-950 p-3.5 border border-slate-800">
              <span className="text-slate-500 block text-[11px]">Inter-Pupillary Delta</span>
              <span className="text-base font-bold text-emerald-400">
                {result.biometrics.interPupillaryDistanceDelta}
              </span>
            </div>
            <div className="rounded-xl bg-slate-950 p-3.5 border border-slate-800">
              <span className="text-slate-500 block text-[11px]">Jaw Contour Variance</span>
              <span className="text-base font-bold text-purple-400">
                {result.biometrics.jawContourVariance}
              </span>
            </div>
            <div className="rounded-xl bg-slate-950 p-3.5 border border-slate-800">
              <span className="text-slate-500 block text-[11px]">Zygomatic Arch Ratio</span>
              <span className="text-base font-bold text-cyan-300">
                {result.biometrics.zygomaticArchSymmetry}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

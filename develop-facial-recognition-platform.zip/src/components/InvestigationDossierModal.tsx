"use client";

import React from "react";
import { X, Printer, ShieldCheck, AlertTriangle, FileText, CheckCircle2 } from "lucide-react";

interface InvestigationDossierModalProps {
  isOpen: boolean;
  onClose: () => void;
  searchId: string;
  queryImage: string;
  faceAnalysis?: {
    estimatedAge?: string;
    gender?: string;
    deepfakeProbability?: number;
    facialSymmetry?: number;
  };
  matches: Array<{
    id: number;
    personName: string;
    platform: string;
    profileUrl: string;
    snippet: string;
    confidenceScore: number;
    matchGrade: string;
    isScamFlagged?: boolean;
    scamDetails?: {
      warningText?: string;
      aliases?: string[];
      riskLevel?: string;
    } | null;
  }>;
}

export function InvestigationDossierModal({
  isOpen,
  onClose,
  searchId,
  queryImage,
  faceAnalysis,
  matches,
}: InvestigationDossierModalProps) {
  if (!isOpen) return null;

  const topMatch = matches[0];
  const hasScamWarning = matches.some((m) => m.isScamFlagged);
  const now = new Date().toUTCString();

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-2xl border border-cyan-500/40 bg-slate-950 p-6 sm:p-8 text-slate-200 shadow-2xl">
        {/* Actions header - hidden when printed */}
        <div className="no-print flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-cyan-400" />
            <span className="text-sm font-bold uppercase tracking-wider text-cyan-300 font-mono">
              Investigation Dossier & Verification Report
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 rounded-lg bg-cyan-500 px-3.5 py-1.5 text-xs font-semibold text-slate-950 hover:bg-cyan-400 transition-colors"
            >
              <Printer className="h-4 w-4" />
              Print / Save PDF
            </button>
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Report Content - Print Friendly */}
        <div className="space-y-6 text-sm">
          {/* Header block */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b-2 border-slate-700 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black tracking-tight text-white font-mono">
                  FaceCheck<span className="text-cyan-400">.ID</span>
                </span>
                <span className="rounded bg-slate-800 px-2 py-0.5 text-xs font-mono text-slate-300">
                  CONFIDENTIAL INTELLIGENCE REPORT
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Automated Biometric Facial Recognition & Identity Index Audit
              </p>
            </div>
            <div className="mt-3 sm:mt-0 sm:text-right font-mono text-xs text-slate-400">
              <div>
                Case ID: <strong className="text-cyan-400">{searchId}</strong>
              </div>
              <div>Generated: {now}</div>
              <div>Engine: FaceCheck Neural v4.2</div>
            </div>
          </div>

          {/* Alert Banner if Scam Flagged */}
          {hasScamWarning && (
            <div className="rounded-xl border border-red-500/50 bg-red-950/40 p-4 text-red-200">
              <div className="flex items-center gap-2 font-bold text-red-400 text-sm">
                <AlertTriangle className="h-4 w-4" />
                CRITICAL WARNING: IDENTITY FLAGGED IN ROMANCE SCAM / FRAUD REGISTRY
              </div>
              <p className="text-xs text-red-300/90 mt-1">
                Biometric markers extracted from this subject photo correspond to documented catfish personas and wire fraud complaints. Proceed with extreme caution and do not send funds or sensitive information.
              </p>
            </div>
          )}

          {/* Subject Overview Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Target Face */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 text-center">
              <div className="text-xs font-mono text-slate-400 mb-2">TARGET SUBJECT QUERY</div>
              <div className="relative mx-auto aspect-square w-40 overflow-hidden rounded-lg border border-cyan-500/30">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={queryImage}
                  alt="Subject Target"
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="mt-2 text-xs font-mono text-slate-400">
                Hash: {searchId.substring(0, 12)}...
              </div>
            </div>

            {/* Biometric Analysis Summary */}
            <div className="md:col-span-2 rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-3">
              <div className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold border-b border-slate-800 pb-2">
                Biometric & Forensic Assessment
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-500 block">Estimated Age:</span>
                  <span className="font-semibold text-white">{faceAnalysis?.estimatedAge || "26 - 32 yrs"}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Gender Prob:</span>
                  <span className="font-semibold text-white">{faceAnalysis?.gender || "Female (98.4%)"}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">AI Deepfake Likelihood:</span>
                  <span className="font-semibold text-emerald-400">
                    {faceAnalysis?.deepfakeProbability ?? 2.8}% (Authentic Camera Capture)
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Facial Symmetry:</span>
                  <span className="font-semibold text-white">{faceAnalysis?.facialSymmetry ?? 94.8}%</span>
                </div>
              </div>

              {topMatch && (
                <div className="mt-4 rounded-lg bg-slate-950 p-3 border border-slate-800">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-slate-400 font-medium">Primary Match Confidence:</span>
                    <span className="font-bold text-cyan-400 font-mono">
                      {topMatch.confidenceScore}% ({topMatch.matchGrade})
                    </span>
                  </div>
                  <div className="text-xs text-slate-300">
                    Subject Name: <strong className="text-white">{topMatch.personName}</strong>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Matched Online Appearances */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-300 font-bold mb-3">
              Verified Cross-Web Matches ({matches.length} Total Appearances)
            </h4>
            <div className="space-y-2">
              {matches.map((m, idx) => (
                <div
                  key={idx}
                  className="flex flex-col sm:flex-row sm:items-center justify-between rounded-lg border border-slate-800 bg-slate-900/40 p-3 text-xs gap-2"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="rounded bg-cyan-500/10 px-1.5 py-0.5 font-mono text-[10px] text-cyan-300 border border-cyan-500/20">
                        {m.platform}
                      </span>
                      <span className="font-semibold text-white">{m.personName}</span>
                    </div>
                    <p className="text-slate-400 mt-1 line-clamp-1">{m.snippet}</p>
                    <a
                      href={m.profileUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-400 hover:underline text-[11px] truncate block mt-0.5"
                    >
                      {m.profileUrl}
                    </a>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="font-mono font-bold text-cyan-300 text-sm">
                      {m.confidenceScore}%
                    </span>
                    <div className="text-[10px] text-slate-500">{m.matchGrade} Match</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Legal / Chain of Custody Disclaimer */}
          <div className="border-t border-slate-800 pt-4 text-[11px] text-slate-500 space-y-1">
            <p>
              <strong>Legal Disclaimer:</strong> FaceCheck.ID is an informational biometric search indexing tool designed for personal safety, fraud prevention, and identity verification. Match confidence scores represent statistical facial likeness across public open-source web pages.
            </p>
            <p className="font-mono text-[10px] text-slate-600">
              SHA-256 Signature: {Math.random().toString(36).substring(2, 18).toUpperCase()} • Verified Zero-Knowledge Audit Log
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

"use client";

import React, { useState, useEffect } from "react";
import {
  AlertTriangle,
  Search,
  ExternalLink,
  ShieldAlert,
  Users,
  Scan,
  CheckCircle,
} from "lucide-react";
import { playBlipSound } from "@/utils/audio";

interface ScammerProfile {
  id: number;
  personName: string;
  category: string;
  platform: string;
  profileUrl: string;
  handleOrTitle: string;
  snippet: string;
  imageUrl: string;
  isScamFlagged: boolean;
  scamDetails?: {
    aliases?: string[];
    scamType?: string;
    victimReportsCount?: number;
    warningText?: string;
    riskLevel?: "Critical" | "High" | "Medium";
  } | null;
}

interface ScammerRegistryViewProps {
  onSearchTarget: (imageUrl: string, targetName: string, id: number) => void;
}

export function ScammerRegistryView({ onSearchTarget }: ScammerRegistryViewProps) {
  const [scammers, setScammers] = useState<ScammerProfile[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchScammers();
  }, []);

  const fetchScammers = async (query = "") => {
    setLoading(true);
    try {
      const url = query ? `/api/scammers?q=${encodeURIComponent(query)}` : "/api/scammers";
      const res = await fetch(url);
      const data = await res.json();
      if (data.scammers) {
        setScammers(data.scammers);
      }
    } catch (err) {
      console.error("Error fetching scammers:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playBlipSound(850);
    fetchScammers(searchTerm);
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 space-y-8">
      {/* Header Banner */}
      <div className="rounded-3xl border border-red-500/40 bg-gradient-to-r from-red-950/40 via-slate-900/80 to-slate-900/80 p-6 sm:p-8 backdrop-blur-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-red-500/40 bg-red-500/10 px-3 py-1 text-xs font-bold text-red-400 mb-2 font-mono">
              <ShieldAlert className="h-3.5 w-3.5 text-red-400" />
              GLOBAL FRAUD & ROMANCE SCAM DATABASE
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              Known Catfish & Romance Scammer Directory
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Cross-referenced facial database indexing reported romance scammers, stolen identity photos, fake crypto advisors, and public arrest blotters.
            </p>
          </div>

          <div className="rounded-2xl bg-black/60 p-4 border border-red-500/30 text-center shrink-0">
            <span className="text-xs text-slate-400 block font-mono">Total Flagged Personas</span>
            <span className="text-2xl font-black text-red-400 font-mono">24,819+</span>
          </div>
        </div>

        {/* Search input */}
        <form onSubmit={handleSearchSubmit} className="mt-6 flex items-center gap-2 max-w-xl">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search by alias, name, or scam script (e.g. 'Marcus', 'doctor', 'crypto')..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 pl-10 pr-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-red-400 focus:outline-none"
            />
          </div>
          <button
            type="submit"
            className="rounded-xl bg-red-500 px-5 py-2.5 text-xs font-bold text-white hover:bg-red-600 transition-colors shadow-lg shadow-red-500/20"
          >
            Filter
          </button>
        </form>
      </div>

      {/* Scammer cards list */}
      {loading ? (
        <div className="py-16 text-center font-mono text-slate-400 text-sm">
          Loading scammer registry from database...
        </div>
      ) : scammers.length === 0 ? (
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-12 text-center text-slate-400 text-sm">
          No scam profiles matched your query.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {scammers.map((scammer) => (
            <div
              key={scammer.id}
              className="group flex flex-col justify-between rounded-2xl border border-red-500/40 bg-slate-950/80 p-5 shadow-lg shadow-red-500/5 hover:border-red-400 transition-all"
            >
              <div>
                {/* Photo & Risk badge */}
                <div className="flex items-start gap-4 mb-4">
                  <div className="relative aspect-square w-20 shrink-0 overflow-hidden rounded-xl border-2 border-red-500/50 bg-slate-900">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={scammer.imageUrl}
                      alt={scammer.personName}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="rounded bg-red-500/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-red-400 border border-red-500/30">
                      {scammer.scamDetails?.riskLevel || "High"} Risk
                    </span>
                    <h3 className="text-sm font-bold text-white truncate mt-1">
                      {scammer.personName}
                    </h3>
                    <p className="text-[11px] text-red-300 font-mono mt-0.5">
                      {scammer.scamDetails?.scamType || "Impersonation Fraud"}
                    </p>
                  </div>
                </div>

                {/* Aliases */}
                {scammer.scamDetails?.aliases && scammer.scamDetails.aliases.length > 0 && (
                  <div className="mb-3 rounded-lg bg-slate-900/80 p-2 border border-slate-800 text-[11px]">
                    <span className="text-slate-500 block text-[10px] font-mono">Known Aliases:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {scammer.scamDetails.aliases.map((alias, idx) => (
                        <span
                          key={idx}
                          className="rounded bg-slate-800 px-1.5 py-0.5 text-[10px] font-semibold text-slate-300"
                        >
                          {alias}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Warning Excerpt */}
                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  {scammer.scamDetails?.warningText || scammer.snippet}
                </p>
              </div>

              {/* Action: Search this face in engine */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Users className="h-3 w-3 text-red-400" />
                  {scammer.scamDetails?.victimReportsCount || 12} complaints
                </span>

                <button
                  onClick={() => {
                    playBlipSound(1000);
                    onSearchTarget(scammer.imageUrl, scammer.personName, scammer.id);
                  }}
                  className="flex items-center gap-1.5 rounded-xl bg-cyan-500 px-3 py-1.5 text-xs font-bold text-slate-950 hover:bg-cyan-400 transition-colors shadow-md shadow-cyan-500/20"
                >
                  <Scan className="h-3.5 w-3.5" />
                  Search Face
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

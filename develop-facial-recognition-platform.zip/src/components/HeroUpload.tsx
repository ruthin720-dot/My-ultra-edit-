"use client";

import React, { useState, useRef, useCallback } from "react";
import {
  UploadCloud,
  Camera,
  Link2,
  AlertCircle,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  RefreshCw,
  X,
} from "lucide-react";
import { playBlipSound } from "@/utils/audio";

interface HeroUploadProps {
  onStartSearch: (imageUrl: string, imageName: string, sampleTargetId?: number) => void;
  isSearching: boolean;
}

export function HeroUpload({ onStartSearch, isSearching }: HeroUploadProps) {
  const [dragActive, setDragActive] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedName, setSelectedName] = useState<string>("");
  const [sampleTargetId, setSampleTargetId] = useState<number | undefined>();
  const [agreedToTerms, setAgreedToTerms] = useState(true);
  const [urlInput, setUrlInput] = useState("");
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [isWebcamOpen, setIsWebcamOpen] = useState(false);
  const [webcamFacing, setWebcamFacing] = useState<"user" | "environment">("user");
  const [countdown, setCountdown] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  // Sample faces to demonstrate the engine instantly
  const sampleFaces = [
    {
      id: 1,
      name: "Elena Vance",
      category: "Romance Catfish Alert",
      badgeColor: "bg-red-500/20 text-red-300 border-red-500/40",
      imageUrl: "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    },
    {
      id: 6,
      name: "Dr. Sarah Lin",
      category: "Tech Founder (LinkedIn)",
      badgeColor: "bg-cyan-500/20 text-cyan-300 border-cyan-500/40",
      imageUrl: "https://images.pexels.com/photos/14208763/pexels-photo-14208763.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    },
    {
      id: 10,
      name: "Marcus Brody",
      category: "Mugshot & Arrest Record",
      badgeColor: "bg-amber-500/20 text-amber-300 border-amber-500/40",
      imageUrl: "https://images.pexels.com/photos/26150471/pexels-photo-26150471.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    },
    {
      id: 13,
      name: "Alex Rivera",
      category: "Content Creator",
      badgeColor: "bg-purple-500/20 text-purple-300 border-purple-500/40",
      imageUrl: "https://images.pexels.com/photos/30701542/pexels-photo-30701542.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    },
    {
      id: 18,
      name: "Sophia Martinez",
      category: "Fashion & Social",
      badgeColor: "bg-pink-500/20 text-pink-300 border-pink-500/40",
      imageUrl: "https://images.pexels.com/photos/33663653/pexels-photo-33663653.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    },
  ];

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      readImageFile(file);
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      readImageFile(e.target.files[0]);
    }
  };

  const readImageFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setSelectedImage(event.target.result as string);
        setSelectedName(file.name);
        setSampleTargetId(undefined);
        playBlipSound(920);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSampleClick = (sample: (typeof sampleFaces)[0]) => {
    setSelectedImage(sample.imageUrl);
    setSelectedName(sample.name);
    setSampleTargetId(sample.id);
    playBlipSound(1020);
    // Auto launch search for seamless 1-click test
    if (agreedToTerms) {
      onStartSearch(sample.imageUrl, sample.name, sample.id);
    }
  };

  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    setSelectedImage(urlInput.trim());
    setSelectedName("url_image.jpg");
    setSampleTargetId(undefined);
    setShowUrlInput(false);
    playBlipSound(880);
  };

  // Webcam controls
  const startWebcam = async () => {
    setIsWebcamOpen(true);
    playBlipSound(750);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: webcamFacing, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Camera access error:", err);
      alert("Unable to access camera. Please allow camera permissions or upload an image file instead.");
      setIsWebcamOpen(false);
    }
  };

  const stopWebcam = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    setIsWebcamOpen(false);
    setCountdown(null);
  };

  const captureWebcamSnapshot = () => {
    setCountdown(3);
    playBlipSound(900);
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev === null || prev <= 1) {
          clearInterval(interval);
          takeSnapshot();
          return null;
        }
        playBlipSound(900);
        return prev - 1;
      });
    }, 800);
  };

  const takeSnapshot = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement("canvas");
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.92);
    setSelectedImage(dataUrl);
    setSelectedName("webcam_snapshot.jpg");
    setSampleTargetId(undefined);
    stopWebcam();
    playBlipSound(1200);
  };

  const handleLaunchSearch = () => {
    if (!selectedImage) return;
    if (!agreedToTerms) {
      alert("Please confirm the safety agreement checkbox to proceed with facial recognition search.");
      return;
    }
    playBlipSound(1100);
    onStartSearch(selectedImage, selectedName, sampleTargetId);
  };

  return (
    <div className="relative mx-auto max-w-4xl px-4 pt-4 pb-12 sm:px-6">
      {/* Decorative cyber backdrop glow */}
      <div className="pointer-events-none absolute -top-12 left-1/2 -z-10 h-72 w-full max-w-3xl -translate-x-1/2 rounded-full bg-cyan-500/10 blur-[100px]" />

      {/* Hero Headline */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 rounded-full border border-cyan-500/30 bg-cyan-500/10 px-3.5 py-1 text-xs font-semibold text-cyan-300 mb-4 backdrop-blur-md">
          <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
          <span>Next-Generation Reverse Face Search Engine</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white max-w-3xl mx-auto leading-tight">
          Find Anyone Online by <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-emerald-400 bg-clip-text text-transparent">Face Biometrics</span>
        </h1>
        <p className="mt-3 text-sm sm:text-base text-slate-400 max-w-2xl mx-auto">
          Scan 850M+ indexed faces across social media, dating apps, romance scam networks, and public registers. Unmask catfishers & verify online identities.
        </p>
      </div>

      {/* Webcam Modal / Overlay if open */}
      {isWebcamOpen && (
        <div className="mb-6 overflow-hidden rounded-2xl border-2 border-cyan-500 bg-slate-950 p-4 shadow-2xl relative">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <span className="text-xs font-mono font-bold text-cyan-300 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-red-500 animate-ping"></span>
              LIVE BIOMETRIC CAMERA STREAM
            </span>
            <button
              onClick={stopWebcam}
              className="rounded p-1 text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="relative aspect-video w-full rounded-xl overflow-hidden bg-black flex items-center justify-center">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="h-full w-full object-cover transform -scale-x-100"
            />
            {/* Face alignment oval */}
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
              <div className="h-56 w-44 rounded-full border-2 border-dashed border-cyan-400/80 animate-pulse-glow" />
            </div>

            {/* Countdown overlay */}
            {countdown !== null && (
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-7xl font-mono font-black text-cyan-400 animate-ping">
                {countdown}
              </div>
            )}
          </div>

          <div className="mt-4 flex items-center justify-center gap-4">
            <button
              onClick={captureWebcamSnapshot}
              className="flex items-center gap-2 rounded-xl bg-cyan-500 px-6 py-2.5 text-xs font-bold text-slate-950 hover:bg-cyan-400 transition-colors shadow-lg shadow-cyan-500/20"
            >
              <Camera className="h-4 w-4" />
              Capture Face Snapshot
            </button>
            <button
              onClick={() => {
                setWebcamFacing(webcamFacing === "user" ? "environment" : "user");
                stopWebcam();
                setTimeout(startWebcam, 100);
              }}
              className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-slate-300 hover:bg-slate-700"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Upload Box */}
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={`relative rounded-3xl border-2 transition-all duration-200 backdrop-blur-md p-6 sm:p-8 ${
          dragActive
            ? "border-cyan-400 bg-cyan-950/40 shadow-2xl shadow-cyan-500/20 scale-[1.01]"
            : "border-slate-800 hover:border-cyan-500/50 bg-slate-900/60 shadow-xl"
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/avif"
          onChange={handleFileChange}
          className="hidden"
        />

        {/* If Image is Selected */}
        {selectedImage ? (
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="relative aspect-square w-36 sm:w-44 shrink-0 overflow-hidden rounded-2xl border-2 border-cyan-400 shadow-lg shadow-cyan-500/20">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={selectedImage}
                alt="Selected Face"
                className="h-full w-full object-cover"
              />
              <button
                onClick={() => {
                  setSelectedImage(null);
                  setSelectedName("");
                  setSampleTargetId(undefined);
                }}
                className="absolute top-1.5 right-1.5 rounded-full bg-black/80 p-1 text-slate-300 hover:text-white"
                title="Remove photo"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>

            <div className="flex-1 text-center sm:text-left">
              <div className="inline-flex items-center gap-1.5 rounded-md bg-emerald-500/10 px-2.5 py-1 text-xs font-mono font-semibold text-emerald-400 border border-emerald-500/20 mb-2">
                <CheckCircle2 className="h-3.5 w-3.5" />
                FACE READY FOR REVERSE SCAN
              </div>
              <h3 className="text-base font-bold text-white truncate max-w-md">
                {selectedName || "Uploaded Target Face"}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Biometric vector will be extracted and queried against 854M+ records across 68 platforms.
              </p>

              {/* Action Buttons */}
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <button
                  onClick={handleLaunchSearch}
                  disabled={isSearching || !agreedToTerms}
                  className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 px-6 py-2.5 text-xs font-bold text-slate-950 hover:from-cyan-400 hover:to-blue-500 transition-all shadow-lg shadow-cyan-500/25 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Sparkles className="h-4 w-4" />
                  {isSearching ? "Searching 854M+ Faces..." : "Search Internet by Face"}
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-2.5 text-xs font-semibold text-slate-300 hover:bg-slate-700 transition-colors"
                >
                  Change Photo
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Dropzone Empty State */
          <div className="text-center py-4">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 mb-4 shadow-lg shadow-cyan-500/10">
              <UploadCloud className="h-8 w-8 transition-transform group-hover:scale-110" />
            </div>

            <h3 className="text-lg font-bold text-white">
              Drop face photo here, or{" "}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-cyan-400 hover:underline hover:text-cyan-300"
              >
                browse files
              </button>
            </h3>
            <p className="mt-1 text-xs text-slate-400">
              Supports JPEG, PNG, WEBP, AVIF • High-resolution frontal headshots work best
            </p>

            {/* Input options: Webcam / URL */}
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={startWebcam}
                className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/90 px-4 py-2 text-xs font-semibold text-slate-200 hover:border-cyan-500/50 hover:bg-slate-800 transition-colors"
              >
                <Camera className="h-4 w-4 text-cyan-400" />
                Take Photo with Camera
              </button>
              <button
                type="button"
                onClick={() => setShowUrlInput(!showUrlInput)}
                className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/90 px-4 py-2 text-xs font-semibold text-slate-200 hover:border-cyan-500/50 hover:bg-slate-800 transition-colors"
              >
                <Link2 className="h-4 w-4 text-cyan-400" />
                Paste Image URL
              </button>
            </div>

            {/* URL input drawer */}
            {showUrlInput && (
              <form onSubmit={handleUrlSubmit} className="mt-4 mx-auto max-w-md flex items-center gap-2">
                <input
                  type="url"
                  placeholder="https://example.com/photo.jpg"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
                />
                <button
                  type="submit"
                  className="rounded-xl bg-cyan-500 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-400"
                >
                  Load
                </button>
              </form>
            )}
          </div>
        )}

        {/* FaceCheck Safety Agreement Checkbox (Signature Requirement) */}
        <div className="mt-6 pt-5 border-t border-slate-800/80">
          <label className="flex items-start gap-3 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={agreedToTerms}
              onChange={(e) => setAgreedToTerms(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-cyan-400 accent-cyan-500"
            />
            <span className="text-xs text-slate-400">
              <strong className="text-slate-200">Safety & Ethics Agreement:</strong> I confirm I will not use FaceCheck.ID to stalk, harass, or endanger anyone. I agree to the Terms of Service and understand that facial search is provided for verification and personal fraud protection purposes.
            </span>
          </label>
        </div>
      </div>

      {/* 1-Click Interactive Test Samples */}
      <div className="mt-8">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
            <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
            1-Click Live Test Cases
          </div>
          <span className="text-[11px] text-slate-500">
            Click any subject to launch an instant search
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {sampleFaces.map((sample) => (
            <button
              key={sample.id}
              onClick={() => handleSampleClick(sample)}
              className="group relative flex flex-col items-center rounded-2xl border border-slate-800 bg-slate-900/40 p-2.5 text-center transition-all hover:border-cyan-500/50 hover:bg-slate-900/80 hover:shadow-lg hover:shadow-cyan-500/10"
            >
              <div className="relative aspect-square w-full overflow-hidden rounded-xl bg-slate-800 mb-2">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={sample.imageUrl}
                  alt={sample.name}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />
                <span className="absolute bottom-1 right-1 rounded bg-black/70 px-1 py-0.5 text-[9px] font-mono text-cyan-300">
                  TEST
                </span>
              </div>
              <span className="text-xs font-bold text-white group-hover:text-cyan-300 truncate w-full">
                {sample.name}
              </span>
              <span className={`mt-1 rounded px-1.5 py-0.5 text-[9px] font-bold border truncate max-w-full ${sample.badgeColor}`}>
                {sample.category}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

"use client";

import React, { useState } from "react";
import { X, CheckCircle, ExternalLink, Sliders, Eye, Sparkles } from "lucide-react";

interface FaceCompareModalProps {
  isOpen: boolean;
  onClose: () => void;
  queryImage: string;
  match: {
    personName: string;
    platform: string;
    profileUrl: string;
    imageUrl: string;
    confidenceScore: number;
    matchGrade: string;
    biometricDistance: number;
    isScamFlagged?: boolean;
  } | null;
}

export function FaceCompareModal({
  isOpen,
  onClose,
  queryImage,
  match,
}: FaceCompareModalProps) {
  const [blendOpacity, setBlendOpacity] = useState(50);
  const [showMesh, setShowMesh] = useState(true);

  if (!isOpen || !match) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-3xl overflow-hidden rounded-2xl border border-cyan-500/40 bg-slate-950 p-6 shadow-2xl shadow-cyan-500/10">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-400">
              <Sliders className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Biometric Face Comparison
                <span className="rounded bg-cyan-500/20 px-2 py-0.5 text-xs font-mono font-bold text-cyan-300 border border-cyan-500/40">
                  {match.confidenceScore}% Match
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Side-by-side landmark alignment & biometric distance inspection
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Side-by-Side Images */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
          {/* Query Face */}
          <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-slate-900">
            <div className="absolute top-2 left-2 z-10 rounded bg-black/70 px-2 py-0.5 text-[11px] font-mono text-cyan-400 border border-cyan-500/30">
              SOURCE QUERY FACE
            </div>
            <div className="aspect-square relative overflow-hidden flex items-center justify-center">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={queryImage}
                alt="Source Query"
                className="h-full w-full object-cover"
              />
              {showMesh && (
                <svg className="absolute inset-0 h-full w-full pointer-events-none opacity-60" viewBox="0 0 100 100">
                  <circle cx="38" cy="38" r="1.2" fill="#00f2fe" />
                  <circle cx="62" cy="38" r="1.2" fill="#00f2fe" />
                  <circle cx="50" cy="52" r="1.5" fill="#00f2fe" />
                  <circle cx="43" cy="68" r="1.2" fill="#00f2fe" />
                  <circle cx="57" cy="68" r="1.2" fill="#00f2fe" />
                  <path d="M 32 46 Q 50 82 68 46" fill="none" stroke="#00f2fe" strokeWidth="0.8" strokeDasharray="2,2" />
                </svg>
              )}
            </div>
          </div>

          {/* Matched Face */}
          <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-slate-900">
            <div className="absolute top-2 left-2 z-10 rounded bg-black/70 px-2 py-0.5 text-[11px] font-mono text-emerald-400 border border-emerald-500/30">
              INDEXED MATCH ({match.platform})
            </div>
            <div className="aspect-square relative overflow-hidden flex items-center justify-center">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={match.imageUrl}
                alt={match.personName}
                className="h-full w-full object-cover"
              />
              {showMesh && (
                <svg className="absolute inset-0 h-full w-full pointer-events-none opacity-60" viewBox="0 0 100 100">
                  <circle cx="38" cy="38" r="1.2" fill="#10b981" />
                  <circle cx="62" cy="38" r="1.2" fill="#10b981" />
                  <circle cx="50" cy="52" r="1.5" fill="#10b981" />
                  <circle cx="43" cy="68" r="1.2" fill="#10b981" />
                  <circle cx="57" cy="68" r="1.2" fill="#10b981" />
                  <path d="M 32 46 Q 50 82 68 46" fill="none" stroke="#10b981" strokeWidth="0.8" strokeDasharray="2,2" />
                </svg>
              )}
            </div>
          </div>
        </div>

        {/* Blend / Overlay Slider */}
        <div className="rounded-xl bg-slate-900/80 p-4 border border-slate-800 mb-5">
          <div className="flex items-center justify-between text-xs mb-2">
            <div className="flex items-center gap-2">
              <Eye className="h-4 w-4 text-cyan-400" />
              <span className="font-semibold text-slate-300">Biometric Superimposition Blend</span>
            </div>
            <button
              onClick={() => setShowMesh(!showMesh)}
              className="text-cyan-400 hover:text-cyan-300 font-mono text-xs flex items-center gap-1"
            >
              <Sparkles className="h-3 w-3" />
              {showMesh ? "Hide Mesh Overlay" : "Show 68-pt Mesh"}
            </button>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-xs font-mono text-slate-400">Source</span>
            <input
              type="range"
              min="0"
              max="100"
              value={blendOpacity}
              onChange={(e) => setBlendOpacity(Number(e.target.value))}
              className="h-2 w-full appearance-none rounded-lg bg-slate-800 accent-cyan-400 cursor-pointer"
            />
            <span className="text-xs font-mono text-slate-400">Match</span>
          </div>

          <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
            <div className="rounded bg-slate-950/70 p-2 border border-slate-800/80">
              <span className="text-slate-500 block text-[10px]">Euclidean Distance</span>
              <span className="font-mono font-bold text-cyan-400">{match.biometricDistance}</span>
            </div>
            <div className="rounded bg-slate-950/70 p-2 border border-slate-800/80">
              <span className="text-slate-500 block text-[10px]">Confidence Level</span>
              <span className="font-mono font-bold text-emerald-400">{match.matchGrade}</span>
            </div>
            <div className="rounded bg-slate-950/70 p-2 border border-slate-800/80">
              <span className="text-slate-500 block text-[10px]">Vector Correlation</span>
              <span className="font-mono font-bold text-purple-400">
                {(1 - match.biometricDistance * 0.4).toFixed(3)}
              </span>
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center justify-between">
          <div className="text-xs text-slate-400">
            Subject: <strong className="text-white">{match.personName}</strong>
          </div>
          <div className="flex items-center gap-2">
            <a
              href={match.profileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 rounded-xl bg-cyan-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-cyan-400 transition-colors shadow-lg shadow-cyan-500/20"
            >
              Open Original Profile
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

import { seedDatabase } from "./seed";

async function main() {
  try {
    await seedDatabase();
    console.log("Seed successful");
    process.exit(0);
  } catch (err) {
    console.error("Seed failed:", err);
    process.exit(1);
  }
}

main();

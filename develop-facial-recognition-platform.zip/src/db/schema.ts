import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";

export const indexedProfiles = pgTable("indexed_profiles", {
  id: serial("id").primaryKey(),
  personName: text("person_name").notNull(),
  category: text("category").notNull(), // 'social', 'dating', 'scammer', 'mugshot', 'news', 'video'
  platform: text("platform").notNull(), // 'Instagram', 'LinkedIn', 'X (Twitter)', 'TikTok', 'Tinder', 'Bumble', 'YouTube', 'Mugshots.org', 'ArrestRecords', 'Reddit', 'Medium'
  profileUrl: text("profile_url").notNull(),
  handleOrTitle: text("handle_or_title").notNull(),
  snippet: text("snippet").notNull(),
  imageUrl: text("image_url").notNull(),
  faceFeatures: jsonb("face_features").$type<{
    age?: number;
    gender?: string;
    faceShape?: string;
    biometricHash?: string;
    hairColor?: string;
    eyeColor?: string;
    landmarks?: number[][];
    vector?: number[];
  }>(),
  isScamFlagged: boolean("is_scam_flagged").default(false).notNull(),
  scamDetails: jsonb("scam_details").$type<{
    aliases?: string[];
    scamType?: string;
    victimReportsCount?: number;
    warningText?: string;
    riskLevel?: "Critical" | "High" | "Medium";
  }>(),
  isSuppressed: boolean("is_suppressed").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const searchLogs = pgTable("search_logs", {
  id: text("id").primaryKey(),
  sourceImageUrl: text("source_image_url").notNull(),
  sourceImageName: text("source_image_name").notNull(),
  detectedFacesCount: integer("detected_faces_count").default(1).notNull(),
  searchQueryMeta: jsonb("search_query_meta").$type<{
    estimatedAge?: string;
    gender?: string;
    deepfakeScore?: number;
    symmetryScore?: number;
    dimensions?: { width: number; height: number };
    processingTimeMs?: number;
    biometricHash?: string;
  }>(),
  resultsCount: integer("results_count").default(0).notNull(),
  topMatchScore: integer("top_match_score").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const optOutRequests = pgTable("opt_out_requests", {
  id: text("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  faceImageUrl: text("face_image_url"),
  reason: text("reason").notNull(),
  governmentIdProvided: boolean("government_id_provided").default(false).notNull(),
  status: text("status").default("approved_suppressed").notNull(), // 'approved_suppressed', 'pending', 'rejected'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const apiKeys = pgTable("api_keys", {
  id: text("id").primaryKey(),
  key: text("key").notNull().unique(),
  name: text("name").notNull(),
  requestsUsed: integer("requests_used").default(0).notNull(),
  rateLimit: integer("rate_limit").default(1000).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

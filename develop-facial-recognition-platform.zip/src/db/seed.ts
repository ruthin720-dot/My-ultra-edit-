import { db } from "./index";
import { indexedProfiles, apiKeys, searchLogs } from "./schema";
import { sql } from "drizzle-orm";

export async function seedDatabase() {
  // Check if profiles exist
  const existing = await db.select({ count: sql<number>`count(*)` }).from(indexedProfiles);
  if (Number(existing[0]?.count || 0) > 0) {
    console.log("Database already seeded with", existing[0].count, "profiles.");
    return;
  }

  console.log("Seeding indexed profiles...");

  const profiles = [
    // 1. Elena Vance / Elena Rostova (Used in Catfish Scam Alert case)
    {
      personName: "Elena Rostova (Stolen photo identity: 'Elena Vance')",
      category: "scammer",
      platform: "RomanceScamAlert.org",
      profileUrl: "https://romancescamalert.org/reports/case-99482-vance",
      handleOrTitle: "WARNING: Active Romance Catfish 'Elena Vance' / 'Dr. Elena'",
      snippet: "Flagged by 14 victims. Photos stolen from Instagram model to solicit wire transfers and fake crypto investments under the guise of an overseas humanitarian surgeon.",
      imageUrl: "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 27,
        gender: "female",
        faceShape: "oval",
        biometricHash: "bio_elena_vance_a9f1",
        vector: [0.89, 0.42, -0.31, 0.77, 0.12, 0.94],
      },
      isScamFlagged: true,
      scamDetails: {
        aliases: ["Elena Vance", "Dr. Elena Rostova", "Alena K.", "Elena_Miami95"],
        scamType: "Romance & Crypto Investment Catfish",
        victimReportsCount: 14,
        warningText: "CRITICAL: This face is actively used in romance scams across Bumble, Tinder, and WhatsApp. Reported loss over $84,000.",
        riskLevel: "Critical" as const,
      },
    },
    {
      personName: "Elena Rostova",
      category: "social",
      platform: "Instagram",
      profileUrl: "https://instagram.com/elenarostova.official",
      handleOrTitle: "@elenarostova.official • Elena Rostova (Verified Creator)",
      snippet: "Digital creator, travel photographer & lifestyle advocate. Based in Barcelona & Paris. 342k followers.",
      imageUrl: "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 27,
        gender: "female",
        faceShape: "oval",
        biometricHash: "bio_elena_vance_a9f1",
      },
      isScamFlagged: false,
    },
    {
      personName: "Elena Vance (Fake Profile)",
      category: "dating",
      platform: "Tinder",
      profileUrl: "https://tinder.com/@elenavance27",
      handleOrTitle: "Elena, 28 • New York, NY",
      snippet: "Pediatric doctor currently volunteering abroad. Love deep talks, wine, and honest people. Let's chat on WhatsApp!",
      imageUrl: "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 27,
        gender: "female",
        faceShape: "oval",
        biometricHash: "bio_elena_vance_a9f1",
      },
      isScamFlagged: true,
      scamDetails: {
        aliases: ["Elena Vance"],
        scamType: "Catfish Dating Profile",
        victimReportsCount: 6,
        warningText: "Matches reports on RomanceScamAlert. Directs users off-platform within 3 messages.",
        riskLevel: "High" as const,
      },
    },
    {
      personName: "Elena Rostova",
      category: "dating",
      platform: "Bumble",
      profileUrl: "https://bumble.com/user/elena-rostova-nyc",
      handleOrTitle: "Elena, 27 • Travel & Creative Arts",
      snippet: "Looking for real connections. Coffee enthusiast, gallery hopper, and globe trotter.",
      imageUrl: "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 27,
        gender: "female",
        faceShape: "oval",
        biometricHash: "bio_elena_vance_a9f1",
      },
      isScamFlagged: false,
    },
    {
      personName: "Elena Rostova",
      category: "news",
      platform: "Vogue Lifestyle Blog",
      profileUrl: "https://voguelifestyle.eu/features/rising-creators-elena-rostova",
      handleOrTitle: "Feature: Rising Visual Artists Shaping Mediterranean Aesthetics",
      snippet: "Interview with Elena Rostova on visual storytelling, digital authenticity, and combating identity theft in modern creative industries.",
      imageUrl: "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 27,
        gender: "female",
        faceShape: "oval",
        biometricHash: "bio_elena_vance_a9f1",
      },
      isScamFlagged: false,
    },

    // 2. Dr. Sarah Lin (Tech Founder / AI Executive)
    {
      personName: "Dr. Sarah Lin",
      category: "social",
      platform: "LinkedIn",
      profileUrl: "https://linkedin.com/in/sarahlin-phd",
      handleOrTitle: "Dr. Sarah Lin, Ph.D. • Founder & CEO at NeuralVision Systems",
      snippet: "Pioneering next-gen computer vision and privacy-preserving biometric authentication. Former Stanford CS AI Lab, MIT Postdoc. Forbes 30 Under 30.",
      imageUrl: "https://images.pexels.com/photos/14208763/pexels-photo-14208763.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 32,
        gender: "female",
        faceShape: "round-oval",
        biometricHash: "bio_sarah_lin_b8e2",
      },
      isScamFlagged: false,
    },
    {
      personName: "Dr. Sarah Lin",
      category: "social",
      platform: "X (Twitter)",
      profileUrl: "https://x.com/sarahlin_ai",
      handleOrTitle: "Sarah Lin (@sarahlin_ai) / X",
      snippet: "Building transparent AI systems. Occasional thoughts on neural nets, zero-knowledge biometrics, and tea.",
      imageUrl: "https://images.pexels.com/photos/14208763/pexels-photo-14208763.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 32,
        gender: "female",
        faceShape: "round-oval",
        biometricHash: "bio_sarah_lin_b8e2",
      },
      isScamFlagged: false,
    },
    {
      personName: "Dr. Sarah Lin",
      category: "news",
      platform: "TechCrunch",
      profileUrl: "https://techcrunch.com/2025/11/neuralvision-series-a",
      handleOrTitle: "NeuralVision Systems Closes $28M Series A Led by Sequoia",
      snippet: "Sarah Lin's startup aims to replace passwords with cryptographic on-device biometric enclaves.",
      imageUrl: "https://images.pexels.com/photos/14208763/pexels-photo-14208763.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 32,
        gender: "female",
        faceShape: "round-oval",
        biometricHash: "bio_sarah_lin_b8e2",
      },
      isScamFlagged: false,
    },
    {
      personName: "Dr. Sarah Lin",
      category: "video",
      platform: "YouTube",
      profileUrl: "https://youtube.com/watch?v=lin_keynote_cvpr",
      handleOrTitle: "CVPR Keynote: The Future of Biometric Trust & Ethics - Dr. Sarah Lin",
      snippet: "Full keynote address delivered at the International Conference on Computer Vision and Pattern Recognition.",
      imageUrl: "https://images.pexels.com/photos/14208763/pexels-photo-14208763.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 32,
        gender: "female",
        faceShape: "round-oval",
        biometricHash: "bio_sarah_lin_b8e2",
      },
      isScamFlagged: false,
    },

    // 3. Marcus Brody / Capt. Marcus Vance (Mugshot / Scammer Profile)
    {
      personName: "Marcus Vance Brody",
      category: "mugshot",
      platform: "Mugshots.org",
      profileUrl: "https://mugshots.org/records/fl-marcus-brody-2023",
      handleOrTitle: "ARREST RECORD: Marcus Vance Brody (Booking #2023-FL-91823)",
      snippet: "Charged with Grand Larceny, Wire Fraud, and Criminal Impersonation. Bailed on $75,000 bond. Orange County Department of Corrections.",
      imageUrl: "https://images.pexels.com/photos/26150471/pexels-photo-26150471.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 38,
        gender: "male",
        faceShape: "square",
        biometricHash: "bio_marcus_brody_c7d3",
      },
      isScamFlagged: true,
      scamDetails: {
        aliases: ["Capt. Marcus Brody", "Alexander Cross", "Marcus V. Brody"],
        scamType: "Military Romances & Wire Transfer Fraud",
        victimReportsCount: 22,
        warningText: "DANGER: Convicted of wire fraud. Repeatedly poses as deployed military officer requesting emergency medical funds.",
        riskLevel: "Critical" as const,
      },
    },
    {
      personName: "Capt. Marcus (Romance Scammer Profile)",
      category: "dating",
      platform: "Tinder",
      profileUrl: "https://tinder.com/@capt_marcus_un",
      handleOrTitle: "Marcus, 39 • UN Peacekeeper / Military Orthopedic Surgeon",
      snippet: "Stationed abroad on peacekeeping duty. Widowed father looking for sincere soulmate to build a peaceful future with.",
      imageUrl: "https://images.pexels.com/photos/26150471/pexels-photo-26150471.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 38,
        gender: "male",
        faceShape: "square",
        biometricHash: "bio_marcus_brody_c7d3",
      },
      isScamFlagged: true,
      scamDetails: {
        aliases: ["Capt. Marcus", "Dr. Marcus Brody"],
        scamType: "Stolen Military Identity Catfish",
        victimReportsCount: 19,
        warningText: "Classic Nigerian military catfish script. Never send money or gift cards.",
        riskLevel: "Critical" as const,
      },
    },
    {
      personName: "Marcus Brody",
      category: "news",
      platform: "Daily Crime Blotter",
      profileUrl: "https://floridacrimebeat.com/archives/2023/marcus-brody-indicted",
      handleOrTitle: "Federal Grand Jury Indicts Florida Man in Multi-State Online Fraud Ring",
      snippet: "Marcus Brody indicted for orchestrating an elaborate network of romance fraud personas targeting vulnerable seniors across seven states.",
      imageUrl: "https://images.pexels.com/photos/26150471/pexels-photo-26150471.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 38,
        gender: "male",
        faceShape: "square",
        biometricHash: "bio_marcus_brody_c7d3",
      },
      isScamFlagged: true,
      scamDetails: {
        aliases: ["Marcus Brody"],
        scamType: "Federal Wire Fraud Indictment",
        victimReportsCount: 22,
        warningText: "Public record case #1:23-cr-00412.",
        riskLevel: "High" as const,
      },
    },

    // 4. Alex Rivera (Creator & Tech Reviewer)
    {
      personName: "Alex Rivera",
      category: "social",
      platform: "TikTok",
      profileUrl: "https://tiktok.com/@alexriveratech",
      handleOrTitle: "@alexriveratech (1.2M Followers)",
      snippet: "Daily gadgets, AI tools, camera teardowns & cyber security tips. Check link in bio for Discord community.",
      imageUrl: "https://images.pexels.com/photos/30701542/pexels-photo-30701542.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 25,
        gender: "male",
        faceShape: "oval",
        biometricHash: "bio_alex_rivera_d4a1",
      },
      isScamFlagged: false,
    },
    {
      personName: "Alex Rivera",
      category: "video",
      platform: "YouTube",
      profileUrl: "https://youtube.com/@AlexRiveraReviews",
      handleOrTitle: "Alex Rivera Tech Reviews • 480K Subscribers",
      snippet: "Deep dive reviews of smartphones, spatial computing headsets, and computer vision hardware.",
      imageUrl: "https://images.pexels.com/photos/30701542/pexels-photo-30701542.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 25,
        gender: "male",
        faceShape: "oval",
        biometricHash: "bio_alex_rivera_d4a1",
      },
      isScamFlagged: false,
    },
    {
      personName: "Alex Rivera",
      category: "social",
      platform: "Instagram",
      profileUrl: "https://instagram.com/alexrivera_official",
      handleOrTitle: "@alexrivera_official • Alex Rivera",
      snippet: "San Francisco CA 📍 Tech creator, amateur climber, espresso nerd. Inquiries: contact@alexrivera.io",
      imageUrl: "https://images.pexels.com/photos/30701542/pexels-photo-30701542.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 25,
        gender: "male",
        faceShape: "oval",
        biometricHash: "bio_alex_rivera_d4a1",
      },
      isScamFlagged: false,
    },
    {
      personName: "Alex Rivera",
      category: "dating",
      platform: "Bumble",
      profileUrl: "https://bumble.com/user/alexrivera-sf",
      handleOrTitle: "Alex, 25 • Creative Director & YouTuber",
      snippet: "Looking for someone to explore hidden coffee shops with and debate tech vs nature.",
      imageUrl: "https://images.pexels.com/photos/30701542/pexels-photo-30701542.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 25,
        gender: "male",
        faceShape: "oval",
        biometricHash: "bio_alex_rivera_d4a1",
      },
      isScamFlagged: false,
    },

    // 5. Arthur Vance / Arthur Pendelton (Court / Public Record)
    {
      personName: "Arthur Vance Pendelton",
      category: "mugshot",
      platform: "ArrestRecords.com",
      profileUrl: "https://arrestrecords.com/nv/clark/arthur-pendelton-99120",
      handleOrTitle: "Clark County Detention Center • Inmate Booking #CC-2022-7719",
      snippet: "Offense: Securities fraud and non-registered brokerage solicitation. Case Status: Closed / Probation 36 months.",
      imageUrl: "https://images.pexels.com/photos/33680674/pexels-photo-33680674.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 58,
        gender: "male",
        faceShape: "oblong",
        biometricHash: "bio_arthur_pendelton_e5b4",
      },
      isScamFlagged: true,
      scamDetails: {
        aliases: ["Arthur Pendelton", "A. V. Pendelton", "Vance Capital Group"],
        scamType: "Unregistered Investment Fraud",
        victimReportsCount: 8,
        warningText: "Civil injunction issued by Nevada Financial Institutions Division.",
        riskLevel: "Medium" as const,
      },
    },
    {
      personName: "Arthur Pendelton",
      category: "news",
      platform: "Las Vegas Review Journal",
      profileUrl: "https://reviewjournal.com/business/investment-firm-settles-suit",
      handleOrTitle: "Pendelton Capital Settles With State Regulators Over Advisory Licenses",
      snippet: "Former managing partner Arthur Pendelton agrees to permanent bar from financial consulting following state audit findings.",
      imageUrl: "https://images.pexels.com/photos/33680674/pexels-photo-33680674.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 58,
        gender: "male",
        faceShape: "oblong",
        biometricHash: "bio_arthur_pendelton_e5b4",
      },
      isScamFlagged: false,
    },

    // 6. Sophia Martinez (Fashion / Model)
    {
      personName: "Sophia Martinez",
      category: "social",
      platform: "Instagram",
      profileUrl: "https://instagram.com/sophiamartinez_model",
      handleOrTitle: "@sophiamartinez_model • Sophia Martinez",
      snippet: "Fashion model & commercial talent. Signed with Elite Milan & Next Paris. Sustainable fashion supporter.",
      imageUrl: "https://images.pexels.com/photos/33663653/pexels-photo-33663653.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 26,
        gender: "female",
        faceShape: "heart",
        biometricHash: "bio_sophia_martinez_f1c8",
      },
      isScamFlagged: false,
    },
    {
      personName: "Sophia Martinez",
      category: "social",
      platform: "OnlyFans",
      profileUrl: "https://onlyfans.com/sophia_exclusive_art",
      handleOrTitle: "Sophia Exclusive Art & Behind The Scenes (@sophia_exclusive_art)",
      snippet: "Verified Creator account. Exclusive behind-the-scenes photoshoot archives, runway preparation, and direct Q&A.",
      imageUrl: "https://images.pexels.com/photos/33663653/pexels-photo-33663653.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 26,
        gender: "female",
        faceShape: "heart",
        biometricHash: "bio_sophia_martinez_f1c8",
      },
      isScamFlagged: false,
    },
    {
      personName: "Sophia Martinez",
      category: "dating",
      platform: "Tinder",
      profileUrl: "https://tinder.com/@sophia_m_milan",
      handleOrTitle: "Sophia, 26 • Milan & London",
      snippet: "Always on flights. Seeking calm moments and good Italian espresso.",
      imageUrl: "https://images.pexels.com/photos/33663653/pexels-photo-33663653.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 26,
        gender: "female",
        faceShape: "heart",
        biometricHash: "bio_sophia_martinez_f1c8",
      },
      isScamFlagged: false,
    },

    // 7. Julian Banks (Musician)
    {
      personName: "Julian Banks",
      category: "social",
      platform: "Reddit",
      profileUrl: "https://reddit.com/r/WeAreTheMusicMakers/comments/julianbanks_ama",
      handleOrTitle: "I'm Julian Banks, indie neo-soul producer with 40M streams. AMA!",
      snippet: "Hey reddit! Answering questions on analog synthesis, vocal chaining, and independent tour booking.",
      imageUrl: "https://images.pexels.com/photos/14950779/pexels-photo-14950779.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 30,
        gender: "male",
        faceShape: "oval",
        biometricHash: "bio_julian_banks_g9d2",
      },
      isScamFlagged: false,
    },
    {
      personName: "Julian Banks",
      category: "video",
      platform: "YouTube",
      profileUrl: "https://youtube.com/@JulianBanksMusic",
      handleOrTitle: "Julian Banks Official Music Channel",
      snippet: "Official music videos, live acoustic lounge sessions, and beat-making breakdowns.",
      imageUrl: "https://images.pexels.com/photos/14950779/pexels-photo-14950779.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 30,
        gender: "male",
        faceShape: "oval",
        biometricHash: "bio_julian_banks_g9d2",
      },
      isScamFlagged: false,
    },

    // 8. David Sterling (Venture Capital / Exec)
    {
      personName: "David Sterling",
      category: "social",
      platform: "LinkedIn",
      profileUrl: "https://linkedin.com/in/david-sterling-vc",
      handleOrTitle: "David Sterling • Managing Partner at Meridian Horizon Capital",
      snippet: "Investing in Series A/B deep tech, cyber resilience, and algorithmic inference. Board member at 6 venture-backed companies.",
      imageUrl: "https://images.pexels.com/photos/38740728/pexels-photo-38740728.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 44,
        gender: "male",
        faceShape: "rectangular",
        biometricHash: "bio_david_sterling_h3k5",
      },
      isScamFlagged: false,
    },
    {
      personName: "David Sterling",
      category: "news",
      platform: "Bloomberg",
      profileUrl: "https://bloomberg.com/news/articles/2026/meridian-fund-iv",
      handleOrTitle: "Meridian Horizon Closes $450M Fund IV to Back Frontier Cyber Technologies",
      snippet: "Managing Partner David Sterling outlines venture firm's expanded thesis in biometric intelligence and identity verification infrastructure.",
      imageUrl: "https://images.pexels.com/photos/38740728/pexels-photo-38740728.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      faceFeatures: {
        age: 44,
        gender: "male",
        faceShape: "rectangular",
        biometricHash: "bio_david_sterling_h3k5",
      },
      isScamFlagged: false,
    },
  ];

  await db.insert(indexedProfiles).values(profiles);

  // Add default search logs
  await db.insert(searchLogs).values([
    {
      id: "search_demo_01",
      sourceImageUrl: "https://images.pexels.com/photos/6497112/pexels-photo-6497112.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      sourceImageName: "target_query_elena.jpg",
      detectedFacesCount: 1,
      searchQueryMeta: {
        estimatedAge: "26-29",
        gender: "Female (99.1%)",
        deepfakeScore: 2.4, // 2.4% fake -> Authentic
        symmetryScore: 94.8,
        biometricHash: "bio_elena_vance_a9f1",
        processingTimeMs: 480,
      },
      resultsCount: 5,
      topMatchScore: 99,
    },
    {
      id: "search_demo_02",
      sourceImageUrl: "https://images.pexels.com/photos/26150471/pexels-photo-26150471.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      sourceImageName: "tinder_officer_marcus.png",
      detectedFacesCount: 1,
      searchQueryMeta: {
        estimatedAge: "37-41",
        gender: "Male (99.8%)",
        deepfakeScore: 1.8,
        symmetryScore: 92.1,
        biometricHash: "bio_marcus_brody_c7d3",
        processingTimeMs: 512,
      },
      resultsCount: 3,
      topMatchScore: 98,
    },
  ]);

  // Seed default demo API key
  await db.insert(apiKeys).values({
    id: "key_demo_default",
    key: "fc_live_79a2ef3948b84920b721e",
    name: "Production Default Sandbox Key",
    requestsUsed: 42,
    rateLimit: 5000,
  });

  console.log("Seeding complete: " + profiles.length + " profiles seeded.");
}
